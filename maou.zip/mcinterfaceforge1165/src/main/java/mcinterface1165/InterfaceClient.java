package mcinterface1165;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.nio.FloatBuffer;

import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.baseclasses.RotationMatrix;
import minecrafttransportsimulator.entities.instances.EntityFluidTank;
import minecrafttransportsimulator.guis.components.AGUIBase;
import minecrafttransportsimulator.guis.instances.GUIPackMissing;
import minecrafttransportsimulator.mcinterface.AWrapperWorld;
import minecrafttransportsimulator.mcinterface.IInterfaceClient;
import minecrafttransportsimulator.mcinterface.IWrapperItemStack;
import minecrafttransportsimulator.mcinterface.IWrapperPlayer;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.packloading.PackParser;
import minecrafttransportsimulator.rendering.RenderText;
import minecrafttransportsimulator.systems.CameraSystem.CameraMode;
import minecrafttransportsimulator.systems.ConfigSystem;
import minecrafttransportsimulator.systems.ControlSystem;
import minecrafttransportsimulator.systems.LanguageSystem;
import net.minecraft.block.SoundType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.settings.PointOfView;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.fluid.Fluid;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.Color;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.registries.ForgeRegistries;

@EventBusSubscriber(Dist.CLIENT)
public class InterfaceClient implements IInterfaceClient {
    private static CameraMode actualCameraMode;
    private static CameraMode cameraModeRequest;
    private static int ticksToCullingWarning = 200;

    @Override
    public boolean isGamePaused() {
        return Minecraft.getInstance().isPaused();
    }

    @Override
    public String getLanguageName() {
        if (Minecraft.getInstance().getLanguageManager() != null) {
            return Minecraft.getInstance().getLanguageManager().getSelected().getCode();
        } else {
            return "en_us";
        }
    }

    @Override
    public List<String> getAllLanguages() {
        List<String> list = new ArrayList<>();
        Minecraft.getInstance().getLanguageManager().getLanguages().forEach(language -> list.add(language.getCode()));
        return list;
    }

    @Override
    public String getFluidName(String fluidID, String fluidMod) {
        for (Entry<RegistryKey<Fluid>, Fluid> fluidEntry : ForgeRegistries.FLUIDS.getEntries()) {
            ResourceLocation fluidLocation = fluidEntry.getKey().location();
            if ((fluidMod.equals(EntityFluidTank.WILDCARD_FLUID_MOD) || fluidLocation.getNamespace().equals(fluidMod)) && fluidLocation.getPath().equals(fluidID)) {
                return new TranslationTextComponent(fluidEntry.getValue().getAttributes().getTranslationKey()).getString();
            }
        }
        return "INVALID";
    }

    @Override
    public Map<String, String> getAllFluidNames() {
        Map<String, String> fluidIDsToNames = new HashMap<>();
        for (Fluid fluid : ForgeRegistries.FLUIDS.getValues()) {
            fluidIDsToNames.put(fluid.getRegistryName().getPath(), new FluidStack(fluid, 1).getDisplayName().getString());
        }
        return fluidIDsToNames;
    }

    @Override
    public boolean isChatOpen() {
        return Minecraft.getInstance().screen instanceof ChatScreen;
    }

    @Override
    public boolean isGUIOpen() {
        return Minecraft.getInstance().screen != null;
    }

    @Override
    public void displayOverlayMessage(String message) {
        Minecraft.getInstance().gui.setOverlayMessage(new StringTextComponent(message), false);
    }

    @Override
    public CameraMode getCameraMode() {
        return actualCameraMode;
    }

    @Override
    public void setCameraMode(CameraMode mode) {
        cameraModeRequest = mode;
    }

    @Override
    public int getCameraDefaultZoom() {
        return 0;
    }

    @Override
    public long getPackedDisplaySize() {
        return (((long) Minecraft.getInstance().getWindow().getGuiScaledWidth()) << Integer.SIZE) | (Minecraft.getInstance().getWindow().getGuiScaledHeight() & 0xffffffffL);
    }

    @Override
    public float getFOV() {
        return (float) Minecraft.getInstance().options.fov;
    }

    @Override
    public void setFOV(float setting) {
        Minecraft.getInstance().options.fov = setting;
    }

    @Override
    public float getMouseSensitivity() {
        return (float) Minecraft.getInstance().options.sensitivity;
    }

    @Override
    public void setMouseSensitivity(float setting) {
        Minecraft.getInstance().options.sensitivity = setting;
    }

    @Override
    public boolean isGUIHidden() {
        return Minecraft.getInstance().options.hideGui;
    }

    @Override
    public void closeGUI() {
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public void setActiveGUI(AGUIBase gui) {
        Minecraft.getInstance().setScreen(new BuilderGUI(gui));
    }

    @Override
    public WrapperWorld getClientWorld() {
        return WrapperWorld.getWrapperFor(Minecraft.getInstance().level);
    }

    @Override
    public WrapperPlayer getClientPlayer() {
        return WrapperPlayer.getWrapperFor(Minecraft.getInstance().player);
    }

    @Override
    public Point3D getCameraPosition() {
        Vector3d cameraOffset = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        mutablePosition.set(cameraOffset.x, cameraOffset.y, cameraOffset.z);
        return mutablePosition;
    }

    private static final Point3D mutablePosition = new Point3D();
    private static final RotationMatrix cameraProjectionOrientation = new RotationMatrix();
    private static final FloatBuffer projectionMatrixBuffer = FloatBuffer.allocate(16);

    @Override
    public Point3D projectToScreen(Point3D worldPos, int screenWidth, int screenHeight) {
        double camX, camY, camZ;
        double fwdX, fwdY, fwdZ;
        double upX, upY, upZ;
        double rgtX, rgtY, rgtZ;

        if (InterfaceEventsEntityRendering.adjustedCamera) {
            camX = InterfaceEventsEntityRendering.cameraAdjustedPosition.x;
            camY = InterfaceEventsEntityRendering.cameraAdjustedPosition.y;
            camZ = InterfaceEventsEntityRendering.cameraAdjustedPosition.z;
            RotationMatrix ori = getCameraProjectionOrientation(InterfaceEventsEntityRendering.cameraAdjustedOrientation);
            fwdX = ori.m02; fwdY = ori.m12; fwdZ = ori.m22;
            upX  = ori.m01; upY  = ori.m11; upZ  = ori.m21;
            // MTS (1,0,0) rotated = camera LEFT (not right); negate to get camera right.
            rgtX = -ori.m00; rgtY = -ori.m10; rgtZ = -ori.m20;
        } else {
            net.minecraft.client.renderer.ActiveRenderInfo camera = Minecraft.getInstance().gameRenderer.getMainCamera();
            net.minecraft.util.math.vector.Vector3d camPos = camera.getPosition();
            camX = camPos.x; camY = camPos.y; camZ = camPos.z;
            net.minecraft.util.math.vector.Vector3f look = camera.getLookVector();
            net.minecraft.util.math.vector.Vector3f up = camera.getUpVector();
            fwdX = look.x(); fwdY = look.y(); fwdZ = look.z();
            upX  = up.x();   upY  = up.y();   upZ  = up.z();
            // getLeftVector() does not exist in 1.16.5; compute right = up × look manually.
            rgtX = upY * fwdZ - upZ * fwdY;
            rgtY = upZ * fwdX - upX * fwdZ;
            rgtZ = upX * fwdY - upY * fwdX;
        }
        if (InterfaceEventsEntityRendering.cameraShakeActive) {
            RotationMatrix ori = InterfaceEventsEntityRendering.cameraShakeProjectionRotation;
            fwdX = ori.m02; fwdY = ori.m12; fwdZ = ori.m22;
            upX  = ori.m01; upY  = ori.m11; upZ  = ori.m21;
            rgtX = -ori.m00; rgtY = -ori.m10; rgtZ = -ori.m20;
        }

        double dx = worldPos.x - camX;
        double dy = worldPos.y - camY;
        double dz = worldPos.z - camZ;

        double depth = dx * fwdX + dy * fwdY + dz * fwdZ;
        if (depth <= 0.001) return null;

        double xView = dx * rgtX + dy * rgtY + dz * rgtZ;
        double yView = dx * upX  + dy * upY  + dz * upZ;

        double fovRad = Math.toRadians(getFOV());
        double tanHalfFov = Math.tan(fovRad / 2.0);
        double aspect = (double) screenWidth / screenHeight;
        double ndcX = xView / (depth * tanHalfFov * aspect);
        double ndcY = yView / (depth * tanHalfFov);
        if (InterfaceRender.projectionMatrix != null) {
            projectionMatrixBuffer.clear();
            InterfaceRender.projectionMatrix.store(projectionMatrixBuffer);
            double projectionScaleX = Math.abs(projectionMatrixBuffer.get(0));
            double projectionScaleY = Math.abs(projectionMatrixBuffer.get(5));
            if (projectionScaleX > 0 && projectionScaleY > 0) {
                ndcX = xView * projectionScaleX / depth;
                ndcY = yView * projectionScaleY / depth;
            }
        }

        if (ndcX < -1.1 || ndcX > 1.1 || ndcY < -1.1 || ndcY > 1.1) return null;

        screenProjectionResult.set(
                (ndcX + 1.0) / 2.0 * screenWidth,
                (1.0 - ndcY) / 2.0 * screenHeight,
                depth);
        return screenProjectionResult;
    }

    private static RotationMatrix getCameraProjectionOrientation(RotationMatrix cameraOrientation) {
        if (actualCameraMode == CameraMode.THIRD_PERSON_INVERTED) {
            cameraProjectionOrientation.angles.set(-cameraOrientation.angles.x, cameraOrientation.angles.y - 180, -cameraOrientation.angles.z);
            cameraProjectionOrientation.updateToAngles();
            return cameraProjectionOrientation;
        } else {
            return cameraOrientation;
        }
    }

    private static final Point3D screenProjectionResult = new Point3D();

    @Override
    public void playBlockBreakSound(Point3D position) {
        BlockPos pos = new BlockPos(position.x, position.y, position.z);
        if (!Minecraft.getInstance().level.isEmptyBlock(pos)) {
            SoundType soundType = Minecraft.getInstance().level.getBlockState(pos).getBlock().getSoundType(Minecraft.getInstance().level.getBlockState(pos), Minecraft.getInstance().player.level, pos, null);
            Minecraft.getInstance().level.playSound(Minecraft.getInstance().player, pos, soundType.getBreakSound(), SoundCategory.BLOCKS, soundType.getVolume(), soundType.getPitch());
        }
    }

    @Override
    public List<String> getTooltipLines(IWrapperItemStack stack) {
        List<String> tooltipText = new ArrayList<>();
        List<ITextComponent> tooltipLines = ((WrapperItemStack) stack).stack.getTooltipLines(Minecraft.getInstance().player, Minecraft.getInstance().options.advancedItemTooltips ? ITooltipFlag.TooltipFlags.ADVANCED : ITooltipFlag.TooltipFlags.NORMAL);
        //Add grey formatting text to non-first line tooltips.
        for (int i = 0; i < tooltipLines.size(); ++i) {
            ITextComponent component = tooltipLines.get(i);
            Style style = component.getStyle();
            String stringToAdd = "";
            if (style.isBold()) {
                stringToAdd += RenderText.FORMATTING_CHAR + RenderText.BOLD_FORMATTING_CHAR;
            }
            if (style.isItalic()) {
                stringToAdd += RenderText.FORMATTING_CHAR + RenderText.ITALIC_FORMATTING_CHAR;
            }
            if (style.isUnderlined()) {
                stringToAdd += RenderText.FORMATTING_CHAR + RenderText.UNDERLINE_FORMATTING_CHAR;
            }
            if (style.isStrikethrough()) {
                stringToAdd += RenderText.FORMATTING_CHAR + RenderText.STRIKETHROUGH_FORMATTING_CHAR;
            }
            if (style.isObfuscated()) {
                stringToAdd += RenderText.FORMATTING_CHAR + RenderText.RANDOM_FORMATTING_CHAR;
            }
            if (style.getColor() != null) {
                TextFormatting legacyColor = null;
                for (TextFormatting format : TextFormatting.values()) {
                    if (format.isColor()) {
                        if (style.getColor().equals(Color.fromLegacyFormat(format))) {
                            legacyColor = format;
                            break;
                        }
                    }
                }
                if (legacyColor != null) {
                    stringToAdd += RenderText.FORMATTING_CHAR + Integer.toHexString(legacyColor.ordinal());
                }
            }
            tooltipText.add(stringToAdd + tooltipLines.get(i).getString());
        }
        return tooltipText;
    }

    /**
     * Tick client-side entities like bullets and particles.
     * These don't get ticked normally due to the world tick event
     * not being called on clients.
     */
    @SubscribeEvent
    public static void onIVClientTick(TickEvent.ClientTickEvent event) {
        IWrapperPlayer player = InterfaceManager.clientInterface.getClientPlayer();
        if (!InterfaceManager.clientInterface.isGamePaused() && player != null) {
            AWrapperWorld world = InterfaceManager.clientInterface.getClientWorld();
            if (world != null) {
                if (event.phase.equals(Phase.START)) {
                    ConfigSystem.displayPendingConfigWarnings(player);
                    ControlSystem.cancelTimedActionsForSpectator(player);
                    if (!player.isSpectator()) {
                        //Handle controls.  This has to happen prior to vehicle updates to ensure click handling is based on current position of the player.
                        ControlSystem.controlGlobal(player);
                        if (((WrapperPlayer) player).player.tickCount % 100 == 0) {
                            if (!InterfaceManager.clientInterface.isGUIOpen() && !PackParser.arePacksPresent()) {
                                new GUIPackMissing();
                            }
                        }
                    }
                    
                    //Need to update world brightness since sky darken isn't calculated normally on clients.
                    ((WrapperWorld) world).world.updateSkyBrightness();

                    world.tickAll(true);

                    //Complain about compats at 10 second mark.
                    if (ConfigSystem.settings.general.performModCompatFunctions.value) {
                    	if(ticksToCullingWarning > 0) {
                    		if(--ticksToCullingWarning == 0) {
                                if (ConfigSystem.client.controlSettings.cullingWarn.value && InterfaceManager.coreInterface.isModPresent("entityculling")) {
                                    player.displayChatMessage(LanguageSystem.SYSTEM_DEBUG, "ENTITY CULLING MOD IS PRESENT.  WHITELIST \"mts:builder_existing\", \"mts:builder_rendering\", AND \"mts:builder_seat\". IN CONFIG FILE OR VEHICLES MAY BE CULLED. (You can turn off this message in IV's client config menu)");
                                }
                                if (InterfaceManager.coreInterface.isModPresent("modernfix")) {
                                    player.displayChatMessage(LanguageSystem.SYSTEM_DEBUG, "IV HAS DETECTED THAT MODERNFIX MOD IS PRESENT.  IF DYNAMIC RESOURCES IS SET TO TRUE IV ITEMS WILL NOT RENDER PROPERLY.");
                                }
                    		}
                    	}
                    }
                } else {
                    world.tickAll(false);
                    
                    //Handle camera requests.
                    if(cameraModeRequest != null) {
                    	switch(cameraModeRequest) {
	                    	case FIRST_PERSON:{
	                    		Minecraft.getInstance().options.setCameraType(PointOfView.FIRST_PERSON);
	                    		break;
	                    	}
	                    	case THIRD_PERSON:{
	                    		Minecraft.getInstance().options.setCameraType(PointOfView.THIRD_PERSON_BACK);
	                    		break;
	                    	}
	                    	case THIRD_PERSON_INVERTED:{
	                    		Minecraft.getInstance().options.setCameraType(PointOfView.THIRD_PERSON_FRONT);
	                    		break;
	                    	}
                    	}
                    	cameraModeRequest = null;
                    }

                    //Update camera state, since this can change depending on tick if we check during renders.
                    PointOfView cameraModeEnum  = Minecraft.getInstance().options.getCameraType();
                    switch(cameraModeEnum) {
                    	case FIRST_PERSON:{
                    		actualCameraMode = CameraMode.FIRST_PERSON;
                    		break;
                    	}
                    	case THIRD_PERSON_BACK:{
                    		actualCameraMode = CameraMode.THIRD_PERSON;
                    		break;
                    	}
                    	case THIRD_PERSON_FRONT:{
                    		actualCameraMode = CameraMode.THIRD_PERSON_INVERTED;
                    		break;
                    	}
                    }
                }
            }
        }
    }
}
