package mcinterface1201.mixin.common;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import mcinterface1201.BuilderEntityExisting;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Pengganti ExplosionEvent.Detonate (Forge).  Posisi ledakan dicatat sebelum entity terkena damage,
 * supaya BuilderEntityExisting tahu bagian kendaraan mana yang kena.
 */
@Mixin(Explosion.class)
public abstract class ExplosionMixin {
    @Shadow
    @Final
    private Level level;

    @Shadow
    public abstract Vec3 getPosition();

    @Inject(method = "explode", at = @At("HEAD"))
    private void iv_onExplode(CallbackInfo ci) {
        BuilderEntityExisting.onIVExplode(level, getPosition());
    }
}
