package mcinterface1201;

import minecrafttransportsimulator.blocks.tileentities.components.ATileEntityBase;
import minecrafttransportsimulator.blocks.tileentities.components.ITileEntityEnergyCharger;
import minecrafttransportsimulator.systems.ConfigSystem;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.fabricmc.fabric.api.transfer.v1.transaction.base.SnapshotParticipant;
import net.minecraft.core.BlockPos;
import team.reborn.energy.api.EnergyStorage;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import mcinterface1201.compat.RegistryObject;

/**
 * Builder for tile entities that transform MC energy into power for other entities.
 *
 * @author don_bruce
 */
public class BuilderTileEntityEnergyCharger extends BuilderTileEntity {
    protected static RegistryObject<BlockEntityType<BuilderTileEntityEnergyCharger>> TE_TYPE2;

    private ITileEntityEnergyCharger charger;
    private static final int MAX_BUFFER = 1000;
    private int buffer;
    private final ChargerStorage energyStorage = new ChargerStorage();

    public BuilderTileEntityEnergyCharger(BlockPos pos, BlockState state) {
        super(TE_TYPE2.get(), pos, state);
    }

    @Override
    protected void setTileEntity(ATileEntityBase<?> tile) {
        super.setTileEntity(tile);
        this.charger = (ITileEntityEnergyCharger) tile;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level.isClientSide && charger != null) {
            //Try and charge the internal TE.
            if (buffer > 0) {
                double amountToCharge = charger.getChargeAmount();
                if (amountToCharge != 0) {
                    int amountToRemoveFromBuffer = (int) (amountToCharge / ConfigSystem.settings.general.rfToElectricityFactor.value);
                    if (amountToRemoveFromBuffer > buffer) {
                        amountToRemoveFromBuffer = buffer;
                        amountToCharge = amountToRemoveFromBuffer * ConfigSystem.settings.general.rfToElectricityFactor.value;
                    }
                    charger.chargeEnergy(amountToCharge);
                    buffer -= amountToRemoveFromBuffer;
                }
            }
        }
    }

    /**Dipanggil InterfaceLoader setelah registry di-flush.  Menggantikan getCapability(ENERGY).*/
    public static void registerStorage() {
        EnergyStorage.SIDED.registerForBlockEntity((be, side) -> be.energyStorage, TE_TYPE2.get());
    }

    /**
     * Penyimpanan energi (Team Reborn Energy API) pengganti IEnergyStorage milik Forge.
     * Hanya bisa menerima energi, tidak bisa diambil keluar.
     */
    private class ChargerStorage extends SnapshotParticipant<Integer> implements EnergyStorage {
        @Override
        public long insert(long maxAmount, TransactionContext transaction) {
            int amountToStore = (int) Math.min(MAX_BUFFER - buffer, maxAmount);
            if (amountToStore > 0) {
                updateSnapshots(transaction);
                buffer += amountToStore;
                return amountToStore;
            }
            return 0;
        }

        @Override
        public long extract(long maxAmount, TransactionContext transaction) {
            return 0;
        }

        @Override
        public boolean supportsExtraction() {
            return false;
        }

        @Override
        public long getAmount() {
            return buffer;
        }

        @Override
        public long getCapacity() {
            return MAX_BUFFER;
        }

        @Override
        protected Integer createSnapshot() {
            return buffer;
        }

        @Override
        protected void readSnapshot(Integer snapshot) {
            buffer = snapshot;
        }
    }
}
