# Port Forge 1.20.1 -> Fabric 1.20.1 (MaouDrift-2 / Immersive Vehicles)

STATUS: **Port kode selesai, tapi BELUM PERNAH DIKOMPILASI.** Ini hasil port tahap 1+2, belum pernah dikompilasi
(sandbox tidak punya akses ke maven Fabric/Minecraft). Kemungkinan besar masih ada error compile
yang baru kelihatan saat build di GitHub Actions.

## Arsitektur
`mccore` (319 file, tidak bergantung ke Minecraft) TIDAK diubah. Yang diport hanya lapisan
`mcinterface` -> modul baru `mcinterfacefabric1201` (salinan dari `mcinterfaceforge1201`).

## Sudah diport (17 dari 23 file yang pakai Forge)
- Registry (DeferredRegister/RegistryObject/ForgeRegistries): shim di `compat/` + 15 file Builder*/Interface*
- InterfaceLoader (+ InterfaceLoaderClient baru): entrypoint `ModInitializer` / `ClientModInitializer`
- InterfaceInput: key mapping, scroll; mixin baru KeyboardInput, KeyboardHandler, MinecraftInteraction
- InterfaceCore, InterfaceClient, InterfaceSound: event tick/unload -> Fabric API
- InterfacePacket (+ InterfacePacketClient): SimpleChannel -> Fabric networking
- BuilderEntityExisting + ExplosionMixin: ExplosionEvent -> mixin
- BuilderTileEntityFluidTank: IFluidHandler -> Fabric Transfer API (mB <-> droplet)
- BuilderTileEntityEnergyCharger: IEnergyStorage -> Team Reborn Energy
- BuilderTileEntityInventoryContainer: IItemHandler -> Container + InventoryStorage
- Build: fabric-loom, fabric.mod.json, mixin config, task `buildFabric1201`, workflow `build-fabric.yml`

## Tahap 2: 6 file terakhir sudah diport (tetap BELUM dikompilasi)
1. InterfaceEventsEntityRendering: kamera/roll via GameRendererMixin + CameraMixin invoker, HUD via GuiMixin, nama via EntityRendererMixin, tangan/lengan via ItemInHandRendererMixin + PlayerRendererMixin
2. WrapperWorld: ServerTickEvents/ServerWorldEvents, tag `c:`, Fabric Transfer API untuk item
3. WrapperEntity: ServerLivingEntityEvents, AttackEntityCallback, AttackBlockCallback, PlayerBlockBreakEvents
4. WrapperItemStack: FuelRegistry, PotionBrewing, FluidStorage.ITEM
5. WrapperPlayer: ExtendedScreenHandlerFactory
6. InterfaceRender: CoreShaderRegistrationCallback + EntityRendererRegistry (InterfaceRender.registerClientEvents)
Semua dipanggil dari InterfaceLoader (registerEvents) dan InterfaceLoaderClient (registerClientEvents).
Tidak ada lagi import net.minecraftforge di modul ini kecuali tidak ada (sudah dicek dengan grep).

## Sengaja dibuang dulu
JEI, Jade, Embeddium mixin, Cold Sweat data (integrasi opsional, bisa ditambah belakangan).

## Cara build
GitHub -> Actions -> "Build Fabric 1.20.1" -> Run workflow (atau `./gradlew buildFabric1201`).
Kalau gagal, kirim log error ke Claude; perbaiki per batch.
