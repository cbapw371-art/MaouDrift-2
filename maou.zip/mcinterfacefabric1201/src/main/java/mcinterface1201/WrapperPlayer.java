package mcinterface1201;

import java.util.HashMap;
import java.util.Map;

import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.items.components.AItemBase;
import minecrafttransportsimulator.entities.instances.EntityInventoryContainer;
import minecrafttransportsimulator.items.instances.ItemItem;
import minecrafttransportsimulator.jsondefs.JSONItem.ItemComponentType;
import minecrafttransportsimulator.mcinterface.IWrapperEntity;
import minecrafttransportsimulator.mcinterface.IWrapperInventory;
import minecrafttransportsimulator.mcinterface.IWrapperItemStack;
import minecrafttransportsimulator.mcinterface.IWrapperPlayer;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.packets.components.APacketBase;
import minecrafttransportsimulator.systems.LanguageSystem.LanguageEntry;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.AABB;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;

public class WrapperPlayer extends WrapperEntity implements IWrapperPlayer {
    private static final Map<Player, WrapperPlayer> playerClientWrappers = new HashMap<>();
    private static final Map<Player, WrapperPlayer> playerServerWrappers = new HashMap<>();

    protected final Player player;

    /**
     * Returns a wrapper instance for the passed-in player instance.
     * Null may be passed-in safely to ease function-forwarding.
     * Note that the wrapped player class MAY be side-specific, so avoid casting
     * the wrapped entity directly if you aren't sure what its class is.
     * Wrapper is cached to avoid re-creating the wrapper each time it is requested.
     */
    public static WrapperPlayer getWrapperFor(Player player) {
        if (player != null) {
            Map<Player, WrapperPlayer> playerWrappers = player.level().isClientSide ? playerClientWrappers : playerServerWrappers;
            WrapperPlayer wrapper = playerWrappers.get(player);
            if (wrapper == null || !wrapper.isValid() || player != wrapper.player) {
                wrapper = new WrapperPlayer(player);
                playerWrappers.put(player, wrapper);
            }
            return wrapper;
        } else {
            return null;
        }
    }

    protected WrapperPlayer(Player player) {
        super(player);
        this.player = player;
    }

    @Override
    public void setPosition(Point3D position, boolean onGround) {
        super.setPosition(position, onGround);
        //Clear active flight when riding, including players who mounted while already flying.
        if (getEntityRiding() != null && !player.isSpectator() && player.getAbilities().flying) {
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
        }
    }

    @Override
    public double getSeatOffset() {
        //Vanilla players have a -0.35 offset, which is horridly wrong.
        //Player legs are 12 pixels, but the player model has a funky scale.
        //It's supposed to be 32px, but is scaled to 30px, so we need to factor that here.
        //Only return this offset if super returns a non-zero number, which indicates we're in a sitting seat.
        if (super.getSeatOffset() != 0) {
            return (-12D / 16D) * (30D / 32D);
        } else {
            return 0;
        }
    }

    @Override
    public boolean isOP() {
        return player.getServer() == null || player.getServer().getPlayerList().getOps().get(player.getGameProfile()) != null || player.getServer().isSingleplayer();
    }

    @Override
    public void displayChatMessage(LanguageEntry language, Object... args) {
        Minecraft.getInstance().gui.getChat().addMessage(Component.literal(String.format(language.getCurrentValue(), args)));
    }

    @Override
    public boolean isCreative() {
        return player.isCreative();
    }

    @Override
    public boolean isSpectator() {
        return player.isSpectator();
    }

    @Override
    public boolean isSneaking() {
        return player.isCrouching();
    }

    @Override
    public boolean isRightHanded() {
        return player.getMainArm() == HumanoidArm.RIGHT;
    }

    @Override
    public IWrapperEntity getLeashedEntity() {
        for (Mob mobEntity : player.level().getEntitiesOfClass(Mob.class, new AABB(player.position().x - 7.0D, player.position().y - 7.0D, player.position().z - 7.0D, player.position().x + 7.0D, player.position().y + 7.0D, player.position().z + 7.0D))) {
            if (mobEntity.isLeashed() && player.equals(mobEntity.getLeashHolder())) {
                mobEntity.dropLeash(true, !player.isCreative());
                return WrapperEntity.getWrapperFor(mobEntity);
            }
        }
        return null;
    }

    @Override
    public boolean isHoldingItemType(ItemComponentType type) {
        AItemBase heldItem = getHeldItem();
        return heldItem instanceof ItemItem && ((ItemItem) heldItem).definition.item.type.equals(type);
    }

    @Override
    public AItemBase getHeldItem() {
        Item heldItem = player.getMainHandItem().getItem();
        return heldItem instanceof IBuilderItemInterface ? ((IBuilderItemInterface) heldItem).getWrappedItem() : null;
    }

    @Override
    public IWrapperItemStack getHeldStack() {
        return new WrapperItemStack(player.getInventory().getItem(getHotbarIndex()));
    }

    @Override
    public void setHeldStack(IWrapperItemStack stack) {
        player.getInventory().setItem(getHotbarIndex(), ((WrapperItemStack) stack).stack);
    }

    @Override
    public int getHotbarIndex() {
        return player.getInventory().selected;
    }

    @Override
    public IWrapperInventory getInventory() {
        return new WrapperInventory(player.getInventory()) {
            @Override
            public int getSize() {
                return player.getInventory().items.size();
            }
        };
    }

    @Override
    public void sendPacket(APacketBase packet) {
        InterfaceManager.packetInterface.sendToPlayer(packet, this);
    }

    @Override
    public void openCraftingGUI() {
        player.openMenu(new SimpleMenuProvider((containerID, playerInventory, player) -> {
            return new CraftingMenu(containerID, playerInventory, ContainerLevelAccess.create(player.level(), player.blockPosition())) {
                @Override
                public boolean stillValid(Player pPlayer) {
                    return true;
                }
            };
        }, Component.literal("")));
    }

    @Override
    public void openInventoryGUI(EntityInventoryContainer inventory, String texture, IWrapperItemStack inventoryItem) {
        int heldPlayerSlot = inventoryItem != null ? getHotbarIndex() : -1;
        player.openMenu(new ExtendedScreenHandlerFactory() {
            @Override
            public void writeScreenOpeningData(ServerPlayer serverPlayer, FriendlyByteBuf data) {
                data.writeUUID(inventory.uniqueUUID);
                data.writeInt(inventory.getSize());
                data.writeInt(inventory.getStackSize());
                data.writeUtf(texture == null ? "" : texture);
                data.writeInt(heldPlayerSlot);
            }

            @Override
            public Component getDisplayName() {
                return Component.literal("");
            }

            @Override
            public AbstractContainerMenu createMenu(int containerID, Inventory playerInventory, Player menuPlayer) {
                return new BuilderInventoryContainerMenu(containerID, playerInventory, inventory, texture, inventoryItem, heldPlayerSlot);
            }
        });
    }

    /**
     * Registers common-side event hooks.  Called once from the mod initializer.
     * Remove all players from our maps if we unload the world.  This will cause duplicates if we don't.
     */
    public static void registerEvents() {
        ServerWorldEvents.UNLOAD.register((server, world) -> playerServerWrappers.keySet().removeIf(entity1 -> world == entity1.level()));
    }

    /**
     * Registers client-only event hooks.  Called from the client entrypoint only.
     */
    public static void registerClientEvents() {
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> playerClientWrappers.clear());
    }
}
