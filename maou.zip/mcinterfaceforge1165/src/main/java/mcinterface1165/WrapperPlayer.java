package mcinterface1165;

import java.util.HashMap;
import java.util.Map;

import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.items.components.AItemBase;
import minecrafttransportsimulator.entities.instances.EntityInventoryContainer;
import minecrafttransportsimulator.items.instances.ItemItem;
import minecrafttransportsimulator.jsondefs.JSONItem.ItemComponentType;
import minecrafttransportsimulator.mcinterface.IWrapperEntity;
import minecrafttransportsimulator.mcinterface.IWrapperInventory;
import minecrafttransportsimulator.mcinterface.IWrapperItemStack;
import minecrafttransportsimulator.mcinterface.IWrapperPlayer;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.packets.components.APacketBase;
import minecrafttransportsimulator.systems.LanguageSystem.LanguageEntry;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.container.SimpleNamedContainerProvider;
import net.minecraft.inventory.container.WorkbenchContainer;
import net.minecraft.item.Item;
import net.minecraft.util.HandSide;
import net.minecraft.util.IWorldPosCallable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.network.NetworkHooks;

@EventBusSubscriber
public class WrapperPlayer extends WrapperEntity implements IWrapperPlayer {
    private static final Map<PlayerEntity, WrapperPlayer> playerClientWrappers = new HashMap<>();
    private static final Map<PlayerEntity, WrapperPlayer> playerServerWrappers = new HashMap<>();

    protected final PlayerEntity player;

    /**
     * Returns a wrapper instance for the passed-in player instance.
     * Null may be passed-in safely to ease function-forwarding.
     * Note that the wrapped player class MAY be side-specific, so avoid casting
     * the wrapped entity directly if you aren't sure what its class is.
     * Wrapper is cached to avoid re-creating the wrapper each time it is requested.
     */
    public static WrapperPlayer getWrapperFor(PlayerEntity player) {
        if (player != null) {
            Map<PlayerEntity, WrapperPlayer> playerWrappers = player.level.isClientSide ? playerClientWrappers : playerServerWrappers;
            WrapperPlayer wrapper = playerWrappers.get(player);
            if (wrapper == null || !wrapper.isValid() || player != wrapper.player) {
                wrapper = new WrapperPlayer(player);
                playerWrappers.put(player, wrapper);
            }
            return wrapper;
        } else {
            return null;
        }
    }

    protected WrapperPlayer(PlayerEntity player) {
        super(player);
        this.player = player;
    }

    @Override
    public void setPosition(Point3D position, boolean onGround) {
        super.setPosition(position, onGround);
        //Clear active flight when riding, including players who mounted while already flying.
        if (getEntityRiding() != null && !player.isSpectator() && player.abilities.flying) {
            player.abilities.flying = false;
            player.onUpdateAbilities();
        }
    }

    @Override
    public double getSeatOffset() {
        //Vanilla players have a -0.35 offset, which is horridly wrong.
        //Player legs are 12 pixels, but the player model has a funky scale.
        //It's supposed to be 32px, but is scaled to 30px, so we need to factor that here.
        //Only return this offset if super returns a non-zero number, which indicates we're in a sitting seat.
        if (super.getSeatOffset() != 0) {
            return (-12D / 16D) * (30D / 32D);
        } else {
            return 0;
        }
    }

    @Override
    public boolean isOP() {
        return player.getServer() == null || player.getServer().getPlayerList().getOps().get(player.getGameProfile()) != null || player.getServer().isSingleplayer();
    }

    @Override
    public void displayChatMessage(LanguageEntry language, Object... args) {
        Minecraft.getInstance().gui.getChat().addMessage(new StringTextComponent(String.format(language.getCurrentValue(), args)));
    }

    @Override
    public boolean isCreative() {
        return player.isCreative();
    }

    @Override
    public boolean isSpectator() {
        return player.isSpectator();
    }

    @Override
    public boolean isSneaking() {
        return player.isCrouching();
    }

    @Override
    public boolean isRightHanded() {
        return player.getMainArm() == HandSide.RIGHT;
    }

    @Override
    public IWrapperEntity getLeashedEntity() {
        for (MobEntity mobEntity : player.level.getLoadedEntitiesOfClass(MobEntity.class, new AxisAlignedBB(player.position().x - 7.0D, player.position().y - 7.0D, player.position().z - 7.0D, player.position().x + 7.0D, player.position().y + 7.0D, player.position().z + 7.0D))) {
            if (mobEntity.isLeashed() && player.equals(mobEntity.getLeashHolder())) {
                mobEntity.dropLeash(true, !player.isCreative());
                return WrapperEntity.getWrapperFor(mobEntity);
            }
        }
        return null;
    }

    @Override
    public boolean isHoldingItemType(ItemComponentType type) {
        AItemBase heldItem = getHeldItem();
        return heldItem instanceof ItemItem && ((ItemItem) heldItem).definition.item.type.equals(type);
    }

    @Override
    public AItemBase getHeldItem() {
        Item heldItem = player.getMainHandItem().getItem();
        return heldItem instanceof IBuilderItemInterface ? ((IBuilderItemInterface) heldItem).getWrappedItem() : null;
    }

    @Override
    public IWrapperItemStack getHeldStack() {
        return new WrapperItemStack(player.inventory.getItem(getHotbarIndex()));
    }

    @Override
    public void setHeldStack(IWrapperItemStack stack) {
        player.inventory.setItem(getHotbarIndex(), ((WrapperItemStack) stack).stack);
    }

    @Override
    public int getHotbarIndex() {
        return player.inventory.selected;
    }

    @Override
    public IWrapperInventory getInventory() {
        return new WrapperInventory(player.inventory) {
            @Override
            public int getSize() {
                return player.inventory.items.size();
            }
        };
    }

    @Override
    public void sendPacket(APacketBase packet) {
        InterfaceManager.packetInterface.sendToPlayer(packet, this);
    }

    @Override
    public void openCraftingGUI() {
        player.openMenu(new SimpleNamedContainerProvider((containerID, playerInventory, player) -> {
            return new WorkbenchContainer(containerID, playerInventory, IWorldPosCallable.create(player.level, player.blockPosition())) {
                @Override
                public boolean stillValid(PlayerEntity pPlayer) {
                    return true;
                }
            };
        }, new StringTextComponent("")));
    }

    @Override
    public void openInventoryGUI(EntityInventoryContainer inventory, String texture, IWrapperItemStack inventoryItem) {
        int heldPlayerSlot = inventoryItem != null ? getHotbarIndex() : -1;
        NetworkHooks.openGui((ServerPlayerEntity) player, new SimpleNamedContainerProvider((containerID, playerInventory, player) ->
            new BuilderInventoryContainerMenu(containerID, playerInventory, inventory, texture, inventoryItem, heldPlayerSlot), new StringTextComponent("")), data -> {
                data.writeUUID(inventory.uniqueUUID);
                data.writeInt(inventory.getSize());
                data.writeInt(inventory.getStackSize());
                data.writeUtf(texture == null ? "" : texture);
                data.writeInt(heldPlayerSlot);
            });
    }

    /**
     * Remove all entities from our maps if we unload the world.  This will cause duplicates if we don't.
     */
    @SubscribeEvent
    public static void onIVWorldUnload(WorldEvent.Unload event) {
        if (event.getWorld().isClientSide()) {
            playerClientWrappers.keySet().removeIf(entity1 -> event.getWorld() == entity1.level);
        } else {
            playerServerWrappers.keySet().removeIf(entity1 -> event.getWorld() == entity1.level);
        }
    }
}
