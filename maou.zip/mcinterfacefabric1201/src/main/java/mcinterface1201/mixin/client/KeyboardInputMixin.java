package mcinterface1201.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import mcinterface1201.InterfaceInput;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.KeyboardInput;

/**Pengganti MovementInputUpdateEvent (Forge): jalan di akhir KeyboardInput.tick().*/
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void iv_onMovementInput(boolean isSneaking, float sneakingSpeedBonus, CallbackInfo ci) {
        if (Minecraft.getInstance().player != null) {
            InterfaceInput.onIVMovementInput(Minecraft.getInstance().player, (KeyboardInput) (Object) this);
        }
    }
}
