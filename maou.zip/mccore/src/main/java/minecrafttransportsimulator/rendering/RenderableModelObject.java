package minecrafttransportsimulator.rendering;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.nio.FloatBuffer;
import java.net.URL;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import minecrafttransportsimulator.baseclasses.AnimationSwitchbox;
import minecrafttransportsimulator.baseclasses.ColorRGB;
import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.baseclasses.RotationMatrix;
import minecrafttransportsimulator.baseclasses.TransformationMatrix;
import minecrafttransportsimulator.baseclasses.TextureOverlaySwitchbox;
import minecrafttransportsimulator.entities.components.AEntityD_Definable;
import minecrafttransportsimulator.entities.instances.APart;
import minecrafttransportsimulator.entities.instances.EntityVehicleF_Physics;
import minecrafttransportsimulator.entities.instances.PartGroundDevice;
import minecrafttransportsimulator.jsondefs.JSONAnimatedObject;
import minecrafttransportsimulator.jsondefs.AJSONMultiModelProvider;
import minecrafttransportsimulator.jsondefs.JSONLight;
import minecrafttransportsimulator.jsondefs.JSONLight.JSONLightBlendableComponent;
import minecrafttransportsimulator.jsondefs.JSONText;
import minecrafttransportsimulator.jsondefs.JSONTextureOverlay;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.packloading.PackResourceLoader;
import minecrafttransportsimulator.packloading.PackResourceLoader.ResourceType;
import minecrafttransportsimulator.rendering.GIFParser.ParsedGIF;
import minecrafttransportsimulator.rendering.RenderableData.LightingMode;
import minecrafttransportsimulator.rendering.dynamiclight.DynamicLightFrame;
import minecrafttransportsimulator.rendering.dynamiclight.DynamicLightOwner;
import minecrafttransportsimulator.rendering.dynamiclight.DynamicLightSystem;
import minecrafttransportsimulator.systems.ConfigSystem;

/**
 * This class represents an object that can be rendered from a model.  This object is a set of
 * faces that are rendered during the main rendering routine.  Various transforms may be performed on
 * this object via the various rendering classes.  These transforms are applied to the mesh prior
 * to rendering, either manipulating the mesh directly, or manipulating the OpenGL state.
 *
 * @author don_bruce
 */
public class RenderableModelObject {
    public final RenderableData renderable;
    private final boolean isWindow;
    private final boolean isOnlineTexture;
    private final JSONAnimatedObject objectDef;
    private final JSONLight lightDef;
    private final AnimationSwitchbox switchbox;
    private final RenderableData interiorWindowRenderable;
    private final RenderableData colorRenderable;
    private final RenderableData flareRenderable;
    private final RenderableData beamRenderable;
    private final RenderableData coverRenderable;
    private final List<TextureOverlayRenderable> textureOverlayRenderables;
    /** Components with their own color or brightness, or a dynamic light. */
    private final List<ComponentRenderables> componentRenderables;
    /** The dynamic light components, in their lamp order ({@link ComponentRenderables#lampIndex}). */
    private final List<JSONLightBlendableComponent> dynamicComponents;
    private DynamicLightOwner dynamicLightOwner;
    private final List<Double[]> treadPoints;
    private boolean onlineTextureReady;

    private static final TransformationMatrix treadPathBaseTransform = new TransformationMatrix();
    private static final RotationMatrix treadRotation = new RotationMatrix();
    private static final float COLOR_OFFSET = RenderableVertices.Z_BUFFER_OFFSET;
    private static final float FLARE_OFFSET = COLOR_OFFSET + RenderableVertices.Z_BUFFER_OFFSET;
    private static final float COVER_OFFSET = FLARE_OFFSET + RenderableVertices.Z_BUFFER_OFFSET;

    private static final Set<String> downloadingTextures = new HashSet<>();
    private static final Set<String> downloadedTextures = new HashSet<>();
    private static final String ERROR_TEXTURE_NAME = "ERROR";
    private static final Map<String, String> erroredTextures = new HashMap<>();
    private static final Map<String, int[]> textureDimensions = new HashMap<>();
    private static final Set<String> invalidTextureDimensions = new HashSet<>();
    private static final Map<RenderableVertices, RenderableVertices> windowVertexObjects = new IdentityHashMap<>();
    private static final Map<RenderableVertices, RenderableVertices> textureOverlayVertexObjects = new IdentityHashMap<>();
    private static boolean errorTextureBound;

    public RenderableModelObject(AEntityD_Definable<?> entity, RenderableVertices vertexObject) {
        super();
        this.isWindow = vertexObject.name.toLowerCase(Locale.ROOT).contains(AModelParser.WINDOW_OBJECT_NAME);
        this.isOnlineTexture = vertexObject.name.toLowerCase(Locale.ROOT).startsWith(AModelParser.ONLINE_TEXTURE_OBJECT_NAME) || vertexObject.name.toLowerCase(Locale.ROOT).endsWith(AModelParser.ONLINE_TEXTURE_OBJECT_NAME);
        this.onlineTextureReady = !isOnlineTexture;
        this.objectDef = entity.animatedObjectDefinitions.get(vertexObject.name);
        this.lightDef = entity.lightObjectDefinitions.get(vertexObject.name);
        this.switchbox = entity.animatedObjectSwitchboxes.get(vertexObject.name);

        //If we are a window, split the model into two parts.  The first will be the exterior which will
        //be our normal model, the second will be a new, inverted, interior model.
        if (isWindow) {
            //Window rendering needs full-texture UVs.  Keep those on a cached copy rather than
            //mutating the parser's shared vertices, since overlays need the original model UV map.
            RenderableVertices windowVertexObject = getWindowVertexObject(vertexObject);
            this.renderable = new RenderableData(windowVertexObject, "mts:textures/rendering/glass.png");
            this.interiorWindowRenderable = new RenderableData(windowVertexObject.createBackface(), "mts:textures/rendering/glass.png");
        } else {
            this.renderable = new RenderableData(vertexObject);
            this.interiorWindowRenderable = null;
        }

        //Create texture overlays.  These intentionally share the model vertices so the original
        //UV map is preserved exactly.  Each RenderableData still owns its texture/render state.
        if (entity.definition.rendering.textureOverlays != null) {
            int overlayCount = entity.definition.rendering.textureOverlays.size();
            this.textureOverlayRenderables = new ArrayList<>(overlayCount);
            RenderableVertices textureOverlayVertexObject = getTextureOverlayVertexObject(vertexObject);
            RenderableVertices overlayBackfaceVertexObject = isWindow ? textureOverlayVertexObject.createBackface() : null;
            for (int overlayIndex = 0; overlayIndex < overlayCount; ++overlayIndex) {
                JSONTextureOverlay overlayDef = entity.definition.rendering.textureOverlays.get(overlayIndex);
                String texture = resolveOverlayTexture(entity.definition, overlayDef.texture);
                RenderableData overlayRenderable = new RenderableData(textureOverlayVertexObject, texture);
                RenderableData interiorOverlayRenderable = overlayBackfaceVertexObject != null ? new RenderableData(overlayBackfaceVertexObject, texture) : null;
                //All overlays need normal alpha compositing for transparent PNG pixels.  This is
                //independent from blendedAnimations, which controls visibility-based fading.
                overlayRenderable.setTransucentOverride();
                overlayRenderable.setTextureClampToTransparent();
                overlayRenderable.setRenderingOrder(overlayCount - overlayIndex);
                if (interiorOverlayRenderable != null) {
                    interiorOverlayRenderable.setTransucentOverride();
                    interiorOverlayRenderable.setTextureClampToTransparent();
                    interiorOverlayRenderable.setRenderingOrder(overlayCount - overlayIndex);
                }
                if (overlayDef.isBright) {
                    overlayRenderable.setLightMode(LightingMode.IGNORE_ALL_LIGHTING);
                    if (interiorOverlayRenderable != null) {
                        interiorOverlayRenderable.setLightMode(LightingMode.IGNORE_ALL_LIGHTING);
                    }
                }
                int[] dimensions = getTextureDimensions(texture);
                textureOverlayRenderables.add(new TextureOverlayRenderable(overlayRenderable, interiorOverlayRenderable, dimensions[0], dimensions[1]));
            }
        } else {
            this.textureOverlayRenderables = null;
        }

        //Create light objects.
        if (lightDef != null) {
            if (lightDef.emissive) {
                this.colorRenderable = new RenderableData(vertexObject.createOverlay(COLOR_OFFSET), "mts:textures/rendering/light.png");
                if (ConfigSystem.client.renderingSettings.lightsTransp.value) {
                    colorRenderable.setTransucentOverride();
                }
            } else {
                this.colorRenderable = null;
            }
            if (lightDef.isBeam) {
                renderable.setTransucentOverride();
            }
            if (lightDef.blendableComponents != null && !lightDef.blendableComponents.isEmpty()) {
                //Components that share the light's color and brightness stay batched in one flare and one beam renderable.
                List<JSONLightBlendableComponent> flareDefs = new ArrayList<>();
                List<JSONLightBlendableComponent> beamDefs = new ArrayList<>();
                List<ComponentRenderables> ownRenderables = new ArrayList<>();
                List<JSONLightBlendableComponent> dynamicDefs = new ArrayList<>();
                for (JSONLightBlendableComponent component : lightDef.blendableComponents) {
                    if (component.hasOwnLighting()) {
                        boolean dynamic = component.isDynamic();
                        ownRenderables.add(new ComponentRenderables(component, dynamic ? dynamicDefs.size() : -1));
                        if (dynamic) {
                            dynamicDefs.add(component);
                        }
                    } else {
                        if (component.flareHeight > 0) {
                            flareDefs.add(component);
                        }
                        if (component.beamDiameter > 0) {
                            beamDefs.add(component);
                        }
                    }
                }
                this.flareRenderable = createFlareRenderable(flareDefs);
                this.beamRenderable = createBeamRenderable(beamDefs);
                this.componentRenderables = ownRenderables.isEmpty() ? null : ownRenderables;
                this.dynamicComponents = dynamicDefs.isEmpty() ? null : dynamicDefs;
            } else {
                this.flareRenderable = null;
                this.beamRenderable = null;
                this.componentRenderables = null;
                this.dynamicComponents = null;
            }
            if (lightDef.covered) {
                this.coverRenderable = new RenderableData(renderable.vertexObject.createOverlay(COVER_OFFSET), "mts:textures/rendering/glass.png");
            } else {
                this.coverRenderable = null;
            }
        } else {
            this.colorRenderable = null;
            this.flareRenderable = null;
            this.beamRenderable = null;
            this.coverRenderable = null;
            this.componentRenderables = null;
            this.dynamicComponents = null;
        }

        //If we are a tread, create tread points.
        if (entity instanceof PartGroundDevice && ((PartGroundDevice) entity).definition.ground.isTread && !((PartGroundDevice) entity).isSpare) {
            this.treadPoints = generateTreads((PartGroundDevice) entity);
        } else {
            this.treadPoints = null;
        }

        //Bind the error texture if we haven't already.
        if (!errorTextureBound) {
            InterfaceManager.renderingInterface.bindURLTexture(ERROR_TEXTURE_NAME, null);
            errorTextureBound = true;
        }
    }

    /**
     * Renders this object, applying any transforms that need to happen.  This method also
     * renders any objects that depend on this object's transforms after rendering.
     */
    public void render(AEntityD_Definable<?> entity, TransformationMatrix transform, boolean blendingEnabled, float partialTicks) {
        //Do pre-render checks based on the object we are rendering.
        //This may block rendering if there are false visibility transforms or the wrong render pass.
        if (shouldRender(entity, blendingEnabled, partialTicks)) {
            //If we are a online texture, bind that one rather than our own.
            //We do this first since we don't need to calculate other stuff if we aren't rendering.
            if (isOnlineTexture) {
                onlineTextureReady = true;
                //Get the texture from the text objects of the entity.
                //If we don't have anything set, we just use the existing texture.
                for (Entry<JSONText, String> textEntry : entity.text.entrySet()) {
                    JSONText textDef = textEntry.getKey();
                    if (textDef.fieldName != null && renderable.vertexObject.name.contains(textDef.fieldName)) {
                        String textValue = entity.text.get(textDef);
                        if (erroredTextures.containsKey(textValue)) {
                            //Error in texture downloading, set fault data before continuing.
                            textEntry.setValue(erroredTextures.get(textValue));
                        }
                        if (textValue.startsWith(ERROR_TEXTURE_NAME)) {
                            //Texture didn't download, set to error texture.
                            renderable.setTexture(ERROR_TEXTURE_NAME);
                        } else if (downloadedTextures.contains(textValue)) {
                            //Good to render, set texture to object and go.
                            renderable.setTexture(textValue);
                        } else if (downloadingTextures.contains(textValue)) {
                            //Still downloading, skip rendering.
                            onlineTextureReady = false;
                            return;
                        } else if (textValue.isEmpty()) {
                            //Don't render since we don't have any text bound here.
                            onlineTextureReady = false;
                            return;
                        } else {
                            //No data at all.  Need to queue up a downloader for this texture.  Do so and skip rendering until it completes.
                            new ConnectorThread(textValue).run();
                            downloadingTextures.add(textValue);
                            onlineTextureReady = false;
                            return;
                        }
                        break;
                    }
                }
            } else if (!isWindow) {
                //Set our standard texture, provided we're not a window.
                //This allows the entity to dynamically change its texture.
                renderable.setTexture(entity.getTexture());
            }

            //Now set dynamic alpha if we have it, since this dictates translucent state.
            if (objectDef != null && objectDef.blendedAnimations && switchbox != null && switchbox.lastVisibilityClock != null) {
                renderable.setAlpha(getBlendedAlpha());
            }

            //If we aren't on the right pass for our main object, and we don't have lights, skip further calcs.
            if (renderable.isTranslucent != blendingEnabled && lightDef == null) {
                return;
            }

            //If we are a light, get lightLevel for later.
            float lightLevel = lightDef != null ? getLightLevel(entity, lightDef) : 0;

            //Apply transforms.
            renderable.transform.set(transform);
            if (switchbox != null) {
                renderable.transform.multiply(switchbox.netMatrix);
            }

            //Do main rendering based on object properties.
            if (treadPoints != null) {
                //Active tread.  Do tread-path rendering instead of normal model.
                renderable.setLightValue(entity.worldLightValue);
                doTreadRendering((PartGroundDevice) entity, renderable, partialTicks);
            } else {
                //Set object states and render.
                boolean isLitTexture = lightDef != null && lightLevel > 0 && !lightDef.emissive && !lightDef.isBeam;
                if ((renderable.isTranslucent && blendingEnabled) || ((isLitTexture && !renderable.isTranslucent) ? (ConfigSystem.client.renderingSettings.lightsTransp.value == blendingEnabled) : (renderable.isTranslucent == blendingEnabled))) {
                    if (lightDef != null && lightDef.isBeam) {
                        //Model that's actually a beam, render it with beam lighting/blending. 
                        renderable.setLightValue(entity.worldLightValue);
                        renderable.setLightMode(ConfigSystem.client.renderingSettings.brightLights.value ? LightingMode.IGNORE_ALL_LIGHTING : LightingMode.NORMAL);
                        renderable.setBlending(ConfigSystem.client.renderingSettings.blendedLights.value);
                        renderable.setAlpha(Math.min((1 - entity.world.getLightBrightness(entity.position, false)) * lightLevel, 1));
                        renderable.render();
                    } else {
                        //Do normal rendering.
                        renderable.setLightValue(entity.worldLightValue);
                        renderable.setLightMode(ConfigSystem.client.renderingSettings.brightLights.value && isLitTexture ? LightingMode.IGNORE_ALL_LIGHTING : LightingMode.NORMAL);
                        renderable.render();

                        //Render interior window if we have one.
                        if (interiorWindowRenderable != null && ConfigSystem.client.renderingSettings.innerWindows.value) {
                            interiorWindowRenderable.setLightValue(renderable.worldLightValue);
                            interiorWindowRenderable.transform.set(renderable.transform);
                            interiorWindowRenderable.render();
                        }
                    }
                }
            }

            //Check if we are a light that's not a beam.  If so, do light-specific rendering.
            if (lightDef != null && !lightDef.isBeam) {
                ColorRGB color = entity.lightColorValues.get(lightDef);
                if (colorRenderable != null && lightLevel > 0) {
                    //Color renderable might or might not be translucent depending on current alpha state.
                    colorRenderable.setAlpha(lightLevel);
                    if (blendingEnabled == colorRenderable.isTranslucent) {
                        colorRenderable.setLightValue(renderable.worldLightValue);
                        colorRenderable.setLightMode(ConfigSystem.client.renderingSettings.brightLights.value ? LightingMode.IGNORE_ALL_LIGHTING : LightingMode.IGNORE_ORIENTATION_LIGHTING);
                        colorRenderable.setColor(color);
                        colorRenderable.transform.set(renderable.transform);
                        colorRenderable.render();
                    }
                }

                //Dynamic light components hand their pose and brightness to the dynamic light system on the solid pass.
                if (!blendingEnabled && dynamicComponents != null && DynamicLightSystem.getMode() != DynamicLightSystem.Mode.OFF) {
                    if (dynamicLightOwner == null) {
                        dynamicLightOwner = DynamicLightSystem.getOwner(this, entity, lightDef, dynamicComponents);
                    }
                    dynamicLightOwner.update(renderable.transform, switchbox != null ? switchbox.netMatrix : null);
                    //A fading object (blendedAnimations) dims its lamps with it.
                    float shown = objectDef != null && objectDef.blendedAnimations ? renderable.alpha : 1;
                    for (DynamicLightOwner.Lamp lamp : dynamicLightOwner.lamps) {
                        lamp.setLighting(shown * lightLevel);
                    }
                }

                //Flares and beams are always rendered on the blended pass since they need to do alpha blending.
                if (blendingEnabled && lightLevel > 0) {
                    //Light flares or beams detected on blended render pass.
                    //First render all flares, then render all beams.
                    float darkness = 1 - entity.world.getLightBrightness(entity.position, false);
                    float blendableBrightness = Math.min(darkness * lightLevel, 1);
                    if (blendableBrightness > 0) {
                        renderFlare(flareRenderable, color, blendableBrightness);
                        renderBeam(beamRenderable, color, blendableBrightness);
                    }
                    if (componentRenderables != null) {
                        renderComponents(entity, color, darkness, lightLevel);
                    }
                }
                if (!blendingEnabled && coverRenderable != null) {
                    //Light cover detected on solid render pass.
                    coverRenderable.setLightValue(renderable.worldLightValue);
                    coverRenderable.setLightMode(ConfigSystem.client.renderingSettings.brightLights.value && lightLevel > 0 ? LightingMode.IGNORE_ALL_LIGHTING : LightingMode.NORMAL);
                    coverRenderable.transform.set(renderable.transform);
                    coverRenderable.render();
                }
            }

            //Render text on this object.  Only do this on the solid pass.
            for (Entry<JSONText, String> textEntry : entity.text.entrySet()) {
                JSONText textDef = textEntry.getKey();
                if (renderable.vertexObject.name.equals(textDef.attachedTo)) {
                    boolean isLitTexture = textDef.lightsUp && entity.renderTextLit();
                    if (isLitTexture ? (ConfigSystem.client.renderingSettings.lightsTransp.value == blendingEnabled) : (renderable.isTranslucent == blendingEnabled)) {
                        RenderText.draw3DText(textEntry.getValue(), entity, renderable.transform, textDef, false, isLitTexture);
                    }
                }
            }
        } else if (!blendingEnabled && dynamicLightOwner != null) {
            //Hidden by its visibility animations: its lamps go dark with it.
            dynamicLightOwner.hide();
        }
    }

    /**
     * For a dynamic light owner whose entity was not drawn this frame: runs this object's animations as a draw would
     * and returns how much of it shows, 0 to 1 (0 hidden by a visibility animation, the alpha of a fading
     * {@code blendedAnimations} object).  {@link #getAnimationMatrix} is then this frame's.
     */
    public float runVisibility(float partialTicks) {
        if (switchbox == null) {
            return 1;
        }
        boolean shown = switchbox.runSwitchbox(partialTicks, false);
        if (objectDef.blendedAnimations) {
            return switchbox.lastVisibilityClock != null ? getBlendedAlpha() : 1;
        }
        return shown ? 1 : 0;
    }

    /** This object's animation matrix as its switchbox last ran, or null without animations. */
    public TransformationMatrix getAnimationMatrix() {
        return switchbox != null ? switchbox.netMatrix : null;
    }

    /** The alpha of a {@code blendedAnimations} object from its switchbox's last visibility value. */
    private float getBlendedAlpha() {
        double min = switchbox.lastVisibilityClock.animation.clampMin;
        double max = switchbox.lastVisibilityClock.animation.clampMax;
        if (switchbox.lastVisibilityValue <= min) {
            return 0;
        } else if (switchbox.lastVisibilityValue >= max) {
            //Need >= here instead of above for things where min/max clamps are equal.
            return 1;
        } else {
            return (float) ((switchbox.lastVisibilityValue - min) / (max - min));
        }
    }

    /**
     * Renders one entity-wide texture overlay over this model object.  The owning entity calls
     * this from the last JSON entry back to entry zero so lower layers are composited first.
     */
    public void renderTextureOverlay(AEntityD_Definable<?> entity, TransformationMatrix transform, boolean blendingEnabled, float partialTicks, int overlayIndex) {
        //Overlay textures always use alpha compositing, so they only belong on the blended pass.
        if (!blendingEnabled || textureOverlayRenderables == null || !onlineTextureReady || overlayIndex < 0 || overlayIndex >= textureOverlayRenderables.size()) {
            return;
        }

        //The layer follows the owning model object's visibility and physical animations.
        if (!shouldRender(entity, blendingEnabled, partialTicks)) {
            return;
        }

        JSONTextureOverlay overlayDef = entity.definition.rendering.textureOverlays.get(overlayIndex);
        TextureOverlaySwitchbox overlaySwitchbox = entity.textureOverlaySwitchboxes.get(overlayDef);
        if (overlaySwitchbox != null) {
            boolean overlayVisible = overlaySwitchbox.runSwitchbox(partialTicks, false);
            if (!overlayDef.blendedAnimations && !overlayVisible) {
                return;
            }
        }

        float alpha = overlayDef.blendedAnimations && overlaySwitchbox != null ? overlaySwitchbox.getVisibilityAlpha() : 1.0F;
        if (objectDef != null && objectDef.blendedAnimations) {
            alpha *= getBlendedAlpha();
        }
        if (alpha <= 0.0F) {
            return;
        }

        TextureOverlayRenderable overlay = textureOverlayRenderables.get(overlayIndex);
        overlay.renderable.setAlpha(alpha);
        overlay.renderable.setLightValue(entity.worldLightValue);

        //The JSON coordinate system is visual texture space: +X is right and +Y is down.
        //Sampling offsets use the inverse sign so the artwork itself moves in that direction.
        double translationX = overlaySwitchbox != null ? overlaySwitchbox.translation.x : 0.0D;
        double translationY = overlaySwitchbox != null ? overlaySwitchbox.translation.y : 0.0D;
        float textureOffsetU = (float) (-(overlayDef.centerPoint.x + translationX) / overlay.textureWidth);
        float textureOffsetV = (float) (-(overlayDef.centerPoint.y + translationY) / overlay.textureHeight);
        float textureScaleU = 1.0F;
        float textureScaleV = 1.0F;
        String normalTexture = entity.getTexture();
        if (!isOnlineTexture && normalTexture != null && !RenderableData.GLOBAL_TEXTURE_NAME.equals(normalTexture)) {
            int[] normalTextureDimensions = getTextureDimensions(normalTexture);
            textureScaleU = normalTextureDimensions[0] / (float) overlay.textureWidth;
            textureScaleV = normalTextureDimensions[1] / (float) overlay.textureHeight;
        }
        overlay.renderable.setTextureScale(textureScaleU, textureScaleV);
        overlay.renderable.setTextureOffset(textureOffsetU, textureOffsetV);

        overlay.renderable.transform.set(transform);
        if (switchbox != null) {
            overlay.renderable.transform.multiply(switchbox.netMatrix);
        }

        if (treadPoints != null) {
            doTreadRendering((PartGroundDevice) entity, overlay.renderable, partialTicks);
        } else {
            overlay.renderable.render();
            if (overlay.interiorRenderable != null && ConfigSystem.client.renderingSettings.innerWindows.value) {
                overlay.interiorRenderable.setAlpha(alpha);
                overlay.interiorRenderable.setLightValue(entity.worldLightValue);
                overlay.interiorRenderable.setTextureScale(textureScaleU, textureScaleV);
                overlay.interiorRenderable.setTextureOffset(textureOffsetU, textureOffsetV);
                overlay.interiorRenderable.transform.set(overlay.renderable.transform);
                overlay.interiorRenderable.render();
            }
        }
    }

    /**
     * Call to destroy this renderable object.  This should be done prior to re-parsing the model
     * as it allows for the freeing of OpenGL resources.
     */
    public void destroy() {
        renderable.destroy();
        if (textureOverlayRenderables != null) {
            textureOverlayRenderables.forEach(overlay -> {
                overlay.renderable.destroy();
                if (overlay.interiorRenderable != null) {
                    overlay.interiorRenderable.destroy();
                }
            });
        }
        if (dynamicLightOwner != null) {
            DynamicLightSystem.removeOwner(this);
            dynamicLightOwner = null;
        }
    }

    /**
     * Returns the brightness of {@code lightDef} on {@code entity} from its current light values, dimmed by the
     * electric power of the vehicle it is on for electric lights.
     */
    public static float getLightLevel(AEntityD_Definable<?> entity, JSONLight lightDef) {
        Float brightness = entity.lightBrightnessValues.get(lightDef);
        float lightLevel = brightness != null ? brightness : 0;
        AEntityD_Definable<?> masterEntity = entity;
        if (masterEntity instanceof APart) {
            masterEntity = ((APart) masterEntity).masterEntity;
        }
        if (lightDef.isElectric && masterEntity instanceof EntityVehicleF_Physics) {
            //Light start dimming at 10V, then go dark at 3V.
            double electricPower = ((EntityVehicleF_Physics) masterEntity).electricPower;
            if (electricPower < 3) {
                lightLevel = 0;
            } else if (electricPower < 10) {
                lightLevel *= (electricPower - 3) / 7D;
            }
        }
        return lightLevel;
    }

    /**
     * Draws the flares and beams of the components with their own lighting, each with its own color and brightness.
     * A dynamic light component draws nothing here while the light pass draws it, and its shader pack fallback while a
     * pack is active.  With dynamic lights off it draws its regular flare and beam, as the others do.  A
     * {@code hideWhenDynLightActive} component draws only while {@link DynamicLightSystem#hidesStandIns} is false.
     */
    private void renderComponents(AEntityD_Definable<?> entity, ColorRGB lightColor, float darkness, float lightLevel) {
        DynamicLightSystem.Mode dynamicMode = DynamicLightSystem.getMode();
        boolean hideStandIns = DynamicLightSystem.hidesStandIns();
        for (ComponentRenderables component : componentRenderables) {
            if (hideStandIns && component.definition.hideWhenDynLightActive) {
                continue;
            }
            if (component.lampIndex >= 0 && dynamicMode != DynamicLightSystem.Mode.OFF) {
                if (dynamicMode == DynamicLightSystem.Mode.FALLBACK && dynamicLightOwner != null) {
                    component.renderFallback(entity, dynamicLightOwner.lamps[component.lampIndex]);
                }
                continue;
            }
            Float componentBrightness = entity.lightComponentBrightnessValues.get(component.definition);
            //A dynamic light's beamIntensity is its light's intensity: its regular flare and beam keep the light's brightness.
            float intensity = component.lampIndex >= 0 ? 1 : component.definition.getIntensity();
            float brightness = Math.min(darkness * lightLevel * (componentBrightness != null ? componentBrightness : 1) * intensity, 1);
            if (brightness > 0) {
                ColorRGB componentColor = entity.lightComponentColorValues.get(component.definition);
                renderFlare(component.flareRenderable, componentColor != null ? componentColor : lightColor, brightness);
                renderBeam(component.beamRenderable, componentColor != null ? componentColor : lightColor, brightness);
            }
        }
    }

    private void renderFlare(RenderableData flare, ColorRGB color, float brightness) {
        if (flare != null && ConfigSystem.client.renderingSettings.renderFlares.value) {
            flare.setLightValue(renderable.worldLightValue);
            flare.setLightMode(ConfigSystem.client.renderingSettings.brightLights.value ? LightingMode.IGNORE_ALL_LIGHTING : LightingMode.NORMAL);
            flare.setColor(color);
            flare.setAlpha(brightness);
            flare.transform.set(renderable.transform);
            flare.render();
        }
    }

    private void renderBeam(RenderableData beam, ColorRGB color, float brightness) {
        if (beam != null && ConfigSystem.client.renderingSettings.renderBeams.value) {
            beam.setLightValue(renderable.worldLightValue);
            beam.setLightMode(ConfigSystem.client.renderingSettings.brightLights.value ? LightingMode.IGNORE_ALL_LIGHTING : LightingMode.NORMAL);
            beam.setBlending(ConfigSystem.client.renderingSettings.blendedLights.value);
            beam.setColor(color);
            beam.setAlpha(brightness);
            beam.transform.set(renderable.transform);
            beam.render();
        }
    }

    private static RenderableData createFlareRenderable(List<JSONLightBlendableComponent> flareDefs) {
        if (flareDefs.isEmpty()) {
            return null;
        }
        List<TransformationMatrix> flareTransforms = new ArrayList<>();
        List<Point3D> flareNormals = new ArrayList<>();
        for (JSONLightBlendableComponent flareDef : flareDefs) {
            //Get the matrix  that is needed to rotate points to the normalized vector.
            TransformationMatrix transform = new TransformationMatrix();
            transform.applyTranslation(flareDef.axis.copy().scale(FLARE_OFFSET).add(flareDef.pos));
            transform.applyRotation(new RotationMatrix().setToVector(flareDef.axis, false));
            transform.applyScaling(flareDef.flareWidth, flareDef.flareHeight, 1);
            flareTransforms.add(transform);
            flareNormals.add(flareDef.axis);
        }
        RenderableData flare = new RenderableData(RenderableVertices.createSprite(flareDefs.size(), flareTransforms, flareNormals), "mts:textures/rendering/lensflare.png");
        flare.setTransucentOverride();
        return flare;
    }

    private static RenderableData createBeamRenderable(List<JSONLightBlendableComponent> beamDefs) {
        if (beamDefs.isEmpty()) {
            return null;
        }
        RenderableData beam = new RenderableData(RenderableVertices.createLightBeams(beamDefs), "mts:textures/rendering/lightbeam.png");
        beam.setTransucentOverride();
        return beam;
    }

    /**
     * The renderables of one component with its own lighting: its regular flare and beam, and for a dynamic light
     * the cone mesh and flare billboard it draws under a shader pack.
     */
    private static class ComponentRenderables {
        private static final int CONE_SIDES = 16;
        private static final int CONE_RINGS = 8;
        /** The cone's radius at the lens, blocks. */
        private static final float CONE_START = 0.06F;
        /** How far a fallback flare sits toward the camera from its lamp: off the lens face, not off the hull. */
        private static final float FLARE_PULL = 0.15F;
        private static final float[] coneXYZ = new float[(CONE_RINGS + 1) * CONE_SIDES * 3];
        private static final float[] coneLevel = new float[(CONE_RINGS + 1) * CONE_SIDES];
        private static final float[][] FLARE_CORNERS = { { -1, -1, 0, 1 }, { -1, 1, 0, 0 }, { 1, 1, 1, 0 }, { 1, -1, 1, 1 } };
        /** Both windings of the flare's two triangles. */
        private static final int[] FLARE_ORDER = { 0, 1, 2, 0, 2, 3, 0, 2, 1, 0, 3, 2 };

        private final JSONLightBlendableComponent definition;
        /** Its lamp in the owner, -1 if not a dynamic light. */
        private final int lampIndex;
        private final RenderableData flareRenderable;
        private final RenderableData beamRenderable;
        /** The shader pack fallback meshes, made on first use. */
        private RenderableData coneRenderable;
        private RenderableData billboardRenderable;

        private ComponentRenderables(JSONLightBlendableComponent definition, int lampIndex) {
            this.definition = definition;
            this.lampIndex = lampIndex;
            List<JSONLightBlendableComponent> list = new ArrayList<>();
            list.add(definition);
            this.flareRenderable = definition.flareHeight > 0 ? createFlareRenderable(list) : null;
            this.beamRenderable = definition.beamDiameter > 0 ? createBeamRenderable(list) : null;
        }

        private void createFallbackRenderables() {
            //Both windings of every face, so a culled pass still shows the cone's far side through its near side.
            coneRenderable = new RenderableData(new RenderableVertices("DYNAMIC_LIGHT_CONE", FloatBuffer.allocate(CONE_RINGS * CONE_SIDES * 12 * 8), false), "mts:textures/rendering/dynamiclight_ramp.png");
            coneRenderable.setTransucentOverride();
            coneRenderable.setLightMode(LightingMode.IGNORE_ALL_LIGHTING);
            billboardRenderable = new RenderableData(new RenderableVertices("DYNAMIC_LIGHT_FLARE", FloatBuffer.allocate(FLARE_ORDER.length * 8), false), "mts:textures/rendering/lensflare.png");
            billboardRenderable.setTransucentOverride();
            billboardRenderable.setLightMode(LightingMode.IGNORE_ALL_LIGHTING);
        }

        /**
         * Draws a dynamic light the way it shows under a shader pack: an open cone mesh from the lens fading along its
         * length and toward its silhouette, and a camera-facing flare.  The vertices are relative to the entity
         * position, the origin the render call sits at, so the transforms are identity.
         */
        private void renderFallback(AEntityD_Definable<?> entity, DynamicLightOwner.Lamp lamp) {
            if (!lamp.showsCone && !lamp.showsFlare) {
                return;
            }
            if (coneRenderable == null) {
                createFallbackRenderables();
            }
            DynamicLightFrame frame = DynamicLightSystem.getFrame();
            float ox = (float) (lamp.x - entity.position.x);
            float oy = (float) (lamp.y - entity.position.y);
            float oz = (float) (lamp.z - entity.position.z);
            float camX = (float) (frame.cameraX - entity.position.x);
            float camY = (float) (frame.cameraY - entity.position.y);
            float camZ = (float) (frame.cameraZ - entity.position.z);
            if (lamp.showsCone) {
                renderCone(lamp, ox, oy, oz, camX, camY, camZ);
            }
            if (lamp.showsFlare) {
                float tx = camX - ox;
                float ty = camY - oy;
                float tz = camZ - oz;
                float distance = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
                if (distance > 1e-4F) {
                    tx /= distance;
                    ty /= distance;
                    tz /= distance;
                    float cx = ox + tx * FLARE_PULL;
                    float cy = oy + ty * FLARE_PULL;
                    float cz = oz + tz * FLARE_PULL;
                    float[] left = frame.cameraLeft;
                    float[] up = frame.cameraUp;
                    float size = lamp.flareSize;
                    FloatBuffer buffer = billboardRenderable.vertexObject.vertices;
                    buffer.clear();
                    for (int index : FLARE_ORDER) {
                        float[] corner = FLARE_CORNERS[index];
                        buffer.put(tx).put(ty).put(tz).put(corner[2]).put(corner[3]);
                        buffer.put(cx + (left[0] * corner[0] + up[0] * corner[1]) * size);
                        buffer.put(cy + (left[1] * corner[0] + up[1] * corner[1]) * size);
                        buffer.put(cz + (left[2] * corner[0] + up[2] * corner[1]) * size);
                    }
                    buffer.flip();
                    billboardRenderable.transform.resetTransforms();
                    billboardRenderable.setColor(lamp.color);
                    billboardRenderable.setAlpha(Math.min(1F, lamp.flareStrength));
                    billboardRenderable.render();
                }
            }
        }

        /**
         * The cone mesh: along the beam a quadratic fade, across it the chord the eye looks through, as in a fog,
         * fading near the camera.  Each vertex's level is the ramp texture's alpha at its U, times the renderable's alpha.
         */
        private void renderCone(DynamicLightOwner.Lamp lamp, float ox, float oy, float oz, float camX, float camY, float camZ) {
            boolean level = Math.abs(lamp.dy) < 0.9F;
            //(level ? up : x) cross direction.
            float ux = level ? lamp.dz : 0;
            float uy = level ? 0 : -lamp.dz;
            float uz = level ? -lamp.dx : lamp.dy;
            float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
            ux /= ul;
            uy /= ul;
            uz /= ul;
            float vx = lamp.dy * uz - lamp.dz * uy;
            float vy = lamp.dz * ux - lamp.dx * uz;
            float vz = lamp.dx * uy - lamp.dy * ux;
            float maxLevel = 0;
            for (int i = 0; i <= CONE_RINGS; i++) {
                float s = (float) i / CONE_RINGS;
                float d = lamp.coneLength * s;
                float radius = CONE_START + d * lamp.coneTan;
                float along = (1F - s) * (1F - s);
                for (int j = 0; j < CONE_SIDES; j++) {
                    double around = j * 2.0 * Math.PI / CONE_SIDES;
                    float c = (float) Math.cos(around);
                    float n = (float) Math.sin(around);
                    float nx = ux * c + vx * n;
                    float ny = uy * c + vy * n;
                    float nz = uz * c + vz * n;
                    float x = ox + lamp.dx * d + nx * radius;
                    float y = oy + lamp.dy * d + ny * radius;
                    float z = oz + lamp.dz * d + nz * radius;
                    float tx = camX - x;
                    float ty = camY - y;
                    float tz = camZ - z;
                    float dist = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
                    float facing = dist > 1e-4F ? Math.abs(nx * tx + ny * ty + nz * tz) / dist : 0F;
                    int k = i * CONE_SIDES + j;
                    coneXYZ[k * 3] = x;
                    coneXYZ[k * 3 + 1] = y;
                    coneXYZ[k * 3 + 2] = z;
                    coneLevel[k] = lamp.coneDensity * along * facing * Math.min(1F, dist * 0.5F);
                    maxLevel = Math.max(maxLevel, coneLevel[k]);
                }
            }
            if (!(maxLevel > 0)) {
                return;
            }
            FloatBuffer buffer = coneRenderable.vertexObject.vertices;
            buffer.clear();
            for (int i = 0; i < CONE_RINGS; i++) {
                for (int j = 0; j < CONE_SIDES; j++) {
                    int j1 = (j + 1) % CONE_SIDES;
                    int a = i * CONE_SIDES + j;
                    int b = (i + 1) * CONE_SIDES + j;
                    int c = (i + 1) * CONE_SIDES + j1;
                    int e = i * CONE_SIDES + j1;
                    putConeTriangle(buffer, a, b, c, maxLevel);
                    putConeTriangle(buffer, a, c, e, maxLevel);
                    putConeTriangle(buffer, a, c, b, maxLevel);
                    putConeTriangle(buffer, a, e, c, maxLevel);
                }
            }
            buffer.flip();
            coneRenderable.transform.resetTransforms();
            coneRenderable.setColor(lamp.color);
            coneRenderable.setAlpha(Math.min(1F, maxLevel));
            coneRenderable.render();
        }

        private static void putConeTriangle(FloatBuffer buffer, int a, int b, int c, float maxLevel) {
            putConeVertex(buffer, a, maxLevel);
            putConeVertex(buffer, b, maxLevel);
            putConeVertex(buffer, c, maxLevel);
        }

        private static void putConeVertex(FloatBuffer buffer, int k, float maxLevel) {
            buffer.put(0).put(1).put(0).put(coneLevel[k] / maxLevel).put(0.5F);
            buffer.put(coneXYZ[k * 3]).put(coneXYZ[k * 3 + 1]).put(coneXYZ[k * 3 + 2]);
        }
    }

    private boolean shouldRender(AEntityD_Definable<?> entity, boolean blendingEnabled, float partialTicks) {
        //Block windows if we have them disabled.
        if (isWindow && !ConfigSystem.client.renderingSettings.renderWindows.value) {
            return false;
        }
        //Block custom light beams if we have them disabled.
        if (lightDef != null && lightDef.isBeam && !ConfigSystem.client.renderingSettings.renderBeams.value) {
            return false;
        }
        //If we have a switchbox, run it once, and if it returns false for a non-blended object, don't render.
        if (switchbox != null) {
            if (objectDef.blendedAnimations) {
                switchbox.runSwitchbox(partialTicks, false);
            } else {
                return switchbox.runSwitchbox(partialTicks, false);
            }
        }
        //No false conditions, return true.
        return true;
    }

    private void doTreadRendering(PartGroundDevice tread, RenderableData renderable, float partialTicks) {
        //Render the treads along their points.
        //We manually set point 0 here due to the fact it's a joint between two differing angles.
        //We also need to translate to that point to start rendering as we're currently at 0,0,0.
        //For each remaining point, we only translate the delta of the point.
        float treadLinearPosition = (float) (tread.getOrCreateVariable("ground_rotation").computeValue(partialTicks) / 360D);
        float treadMovementPercentage = (treadLinearPosition % tread.definition.ground.spacing) / tread.definition.ground.spacing;
        if (treadMovementPercentage < 0) {
            ++treadMovementPercentage;
        }
        Double[] point;
        Double[] nextPoint;
        double yDelta;
        double zDelta;
        double angleDelta;

        //Tread rendering is done via the thing the tread is on, which will assume the part is centered at 0, 0, 0.
        //We need to undo the offset of the tread part for this routine.
        if (!(tread.entityOn instanceof APart)) {
            renderable.transform.applyTranslation(0, -tread.localOffset.y / tread.entityOn.scale.y, -tread.localOffset.z / tread.entityOn.scale.z);
        }

        //Add initial translation for the first point
        point = treadPoints.get(0);
        renderable.transform.applyTranslation(0, point[0], point[1]);

        //Get cycle index for later.
        boolean[] renderIndexes = null;
        if (tread.definition.ground.treadOrder != null) {
            int treadCycleCount = tread.definition.ground.treadOrder.size();
            double treadCycleTotalDistance = treadCycleCount * tread.definition.ground.spacing;
            int treadCycleIndex = (int) Math.floor(treadCycleCount * ((treadLinearPosition % treadCycleTotalDistance) / treadCycleTotalDistance));
            if (treadCycleIndex < 0) {
                //Need to handle negatives if we only go backwards.
                treadCycleIndex += treadCycleCount;
            }
            renderIndexes = new boolean[treadCycleCount];
            for (int i = 0; i < treadCycleCount; ++i) {
                String treadObject = tread.definition.ground.treadOrder.get(i);
                renderIndexes[(i + treadCycleIndex) % treadCycleCount] = treadObject.equals(renderable.vertexObject.name);
            }
        }

        //Now transform all points.
        for (int i = 0; i < treadPoints.size() - 1; ++i) {
            //Update variables.
            //If we're at the last point, set the next point to the first point.
            //Also adjust angle delta, as it'll likely be almost 360 and needs to be adjusted for this.
            point = treadPoints.get(i);
            if (i == treadPoints.size() - 1) {
                nextPoint = treadPoints.get(0);
                angleDelta = (nextPoint[2] + 360) - point[2];
            } else {
                nextPoint = treadPoints.get(i + 1);
                angleDelta = nextPoint[2] - point[2];
            }
            yDelta = nextPoint[0] - point[0];
            zDelta = nextPoint[1] - point[1];

            //If our angle delta is greater than 180, we can assume that we're inverted.
            //This happens when we cross the 360 degree rotation barrier.
            if (angleDelta > 180) {
                angleDelta -= 360;
            } else if (angleDelta < -180) {
                angleDelta += 360;
            }

            //Check if we should render this object as a link in this position.
            //This is normally true, but for patterns we need to only render in specific spots.
            if (renderIndexes != null && !renderIndexes[i % renderIndexes.length]) {
                renderable.transform.applyTranslation(0, yDelta, zDelta);
                continue;
            }

            //Translate to the current position of the tread based on the percent it has moved.
            //This is determined by partial ticks and actual tread position.
            //Once there, render the tread.  Then translate the remainder of the way to prepare
            //to render the next tread.
            renderable.transform.applyTranslation(0, yDelta * treadMovementPercentage, zDelta * treadMovementPercentage);

            //If there's no rotation to the point, and no delta between points, don't do rotation.  That's just extra math.
            //Do note that the model needs to be rotated 180 on the X-axis due to all our points
            //assuming a YZ coordinate system with 0 degrees rotation being in +Y (just how the math comes out).
            //This is why 180 is added to all points cached in the operations above.
            if (point[2] != 0 || angleDelta != 0) {
                //We can't use a running rotation here as we'll end up translating in the rotated
                //coordinate system.  To combat this, we translate like normal, but then push a
                //stack and rotate prior to rendering.  This keeps us from having to do another
                //rotation to get the old coordinate system back.
                treadPathBaseTransform.set(renderable.transform);
                treadRotation.setToAxisAngle(1, 0, 0, point[2] + angleDelta * treadMovementPercentage);
                renderable.transform.applyRotation(treadRotation);
                renderable.render();
                renderable.transform.set(treadPathBaseTransform);
            } else {
                //Just render as normal as we didn't rotate.
                renderable.render();
            }

            //Add remaining translation.
            renderable.transform.applyTranslation(0, yDelta * (1 - treadMovementPercentage), zDelta * (1 - treadMovementPercentage));
        }
    }

    private static <TreadEntity extends AEntityD_Definable<?>> List<Double[]> generateTreads(PartGroundDevice tread) {
        //If we don't have the deltas, calculate them based on the points of the rollers defined in the JSON.			
        //Search through rotatable parts on the model and grab the rollers.
        List<RenderableVertices> parsedModel = AModelParser.parseModel(tread.entityOn.definition.getModelLocation(tread.entityOn.definition.definitions.get(0)), true);
        List<TreadRoller> rollers = new ArrayList<>();
        if (tread.placementDefinition.treadPath == null) {
            throw new IllegalArgumentException("No tread path found for part slot on " + tread.entityOn + "!");
        }
        for (String rollerName : tread.placementDefinition.treadPath) {
            boolean foundRoller = false;
            for (RenderableVertices modelObject : parsedModel) {
                if (modelObject.name.equals(rollerName)) {
                    rollers.add(new TreadRoller(modelObject));
                    foundRoller = true;
                    break;
                }
            }
            if (!foundRoller) {
                InterfaceManager.coreInterface.logError("Could not create tread path for " + tread.entityOn + " due to missing roller " + rollerName + " in the model.  Skipping tread animation for this object.");
                return null;
            }
        }

        //Now that we have all the rollers, we can start calculating points.
        //First calculate the endpoints on the rollers by calling the calculation method.
        for (int i = 0; i < rollers.size(); ++i) {
            if (i < rollers.size() - 1) {
                rollers.get(i).calculateEndpoints(rollers.get(i + 1));
            } else {
                rollers.get(i).calculateEndpoints(rollers.get(0));
            }
        }

        //We need to ensure the endpoints are all angle-aligned.
        //It's possible to have a start angle of -181 and end angle of
        //181, which is really just 2 degress of angle (179-181).
        //To do this, we set the start angle of roller 1 to be 180, 
        //or downward-facing.  From there, we add angles to align things.
        //At the end, we should have a total angle of 540, or 180 + 360.
        rollers.get(0).setEndAngle(180);
        for (int i = 1; i < rollers.size(); ++i) {
            TreadRoller roller = rollers.get(i);
            TreadRoller priorRoller = rollers.get(i - 1);

            //Set the start angle to the end angle of the prior roller, then check for validity.
            roller.startAngle = i == 1 ? 180 : priorRoller.endAngle;

            //Roller angle delta  should be within -30-330 degrees.
            //Positive angles are standard, but negative are possible for concave routing points.
            while (roller.endAngle < roller.startAngle - 30) {
                roller.endAngle += 360;
            }
            while (roller.endAngle > roller.startAngle + 330) {
                roller.endAngle -= 360;
            }

            if (roller.endAngle < roller.startAngle) {
                //We have a concave roller.  Set our start and end angle to the midpoint of their current values.
                //This aligns the point on the roller to the center of concavity.
                double midPoint = roller.endAngle + (roller.startAngle - roller.endAngle) / 2D;
                roller.startAngle = midPoint;
                roller.endAngle = midPoint;
            }

            //Roller angles are bound.  Set our start and end angle values.
            roller.setStartAngle(roller.startAngle);
            roller.setEndAngle(roller.endAngle);
        }
        //Set the start angle to match the end angle of the last roller, rather than the 180 we set.
        rollers.get(0).setStartAngle(rollers.get(rollers.size() - 1).endAngle);

        //Now that the endpoints are set, we can calculate the path.
        //Do this by following the start and end points at small increments.
        //First calculate the total path length, and determine the optimum spacing.
        //This is the closest value to the definition's tread spacing.
        double totalPathLength = 0;
        for (int i = 0; i < rollers.size(); ++i) {
            //Get roller and add roller path contribution.
            TreadRoller roller = rollers.get(i);
            double angleDelta = roller.endAngle - roller.startAngle;
            if (i == 0) {
                //Need to add 360 rev for angle delta, as this will be this way from the tread going around the path.
                angleDelta += 360;
            }
            totalPathLength += 2 * Math.PI * roller.radius * angleDelta / 360D;

            //Get next roller and add distance path contribution.
            //For points that start and end at an angle of around 0 (top of rollers) we add droop.
            //This is a hyperbolic function, so we need to calculate the integral value to account for the path.
            TreadRoller nextRoller = i == rollers.size() - 1 ? rollers.get(0) : rollers.get(i + 1);
            double straightPathLength = Math.hypot(nextRoller.startY - roller.endY, nextRoller.startZ - roller.endZ);
            if (tread.placementDefinition.treadDroopConstant > 0 && (roller.endAngle % 360 < 10 || roller.endAngle % 360 > 350) && (nextRoller.startAngle % 360 < 10 || nextRoller.startAngle % 360 > 350)) {
                //Catenary path length is a*singh(x/a), a is droop constant, x will be 1/2 total catenary distance due to symmetry, multiply this distance by 2 for total droop.
                totalPathLength += 2D * tread.placementDefinition.treadDroopConstant * Math.sinh((straightPathLength / 2D) / tread.placementDefinition.treadDroopConstant);
            } else {
                totalPathLength += straightPathLength;
            }
        }

        double deltaDist = tread.definition.ground.spacing + (totalPathLength % tread.definition.ground.spacing) / (totalPathLength / tread.definition.ground.spacing);
        double leftoverPathLength = 0;
        double yPoint = 0;
        double zPoint = 0;
        List<Double[]> points = new ArrayList<>();
        for (int i = 0; i < rollers.size(); ++i) {
            TreadRoller roller = rollers.get(i);
            //Follow the curve of the roller from the start and end point.
            //Do this until we don't have enough roller path left to make a point.
            //If we have any remaining path from a prior operation, we
            //need to offset our first point on the roller path to account for it.
            //It can very well be that this remainder will be more than the path length
            //of the roller.  If so, we just skip the roller entirely.
            //For the first roller we need to do some special math, as the angles will be inverted
            //For start and end due to the tread making a full 360 path.
            double currentAngle = roller.startAngle;
            double angleDelta = roller.endAngle - roller.startAngle;
            if (i == 0) {
                //Need to add 360 rev for angle delta, as this will be this way from the tread going around the path.
                angleDelta += 360;
            }
            double rollerPathLength = 2 * Math.PI * roller.radius * angleDelta / 360D;

            //Add the first point here, and add more as we follow the path.
            if (i == 0) {
                yPoint = roller.centerPoint.y + roller.radius * Math.cos(Math.toRadians(currentAngle));
                zPoint = roller.centerPoint.z + roller.radius * Math.sin(Math.toRadians(currentAngle));
                points.add(new Double[]{yPoint, zPoint, currentAngle + 180});
            }

            //If we have any leftover straight path, account for it here to keep spacing consistent.
            //We will need to interpolate the point that the straight path would have gone to, but
            //take our rotation angle into account.  Only do this if we have enough of a path to do so.
            //If not, we should just skip this roller as we can't put any points on it.
            if (deltaDist - leftoverPathLength < rollerPathLength) {
                if (leftoverPathLength > 0) {
                    //Go backwards on the roller so when we do our next operation, we align with a new point.
                    //This ensures the new point will be closer to the start of the roller than normal.
                    //Make a new point that's a specific amount of path-movement along this roller.
                    //Then increment currentAngle to account for the new point made.
                    //We use the circumference of the roller and the remaining path to find out the amount to adjust.
                    currentAngle -= 360D * leftoverPathLength / roller.circumference;
                    rollerPathLength += leftoverPathLength;
                    leftoverPathLength = 0;
                }

                while (rollerPathLength > deltaDist) {
                    //Go to and add the next point on the roller path.
                    rollerPathLength -= deltaDist;
                    currentAngle += 360D * (deltaDist / roller.circumference);
                    yPoint = roller.centerPoint.y + roller.radius * Math.cos(Math.toRadians(currentAngle));
                    zPoint = roller.centerPoint.z + roller.radius * Math.sin(Math.toRadians(currentAngle));
                    points.add(new Double[]{yPoint, zPoint, currentAngle + 180});
                }
            }

            //Done following roller, set angle to roller end angle to prevent slight FPEs.
            currentAngle = roller.endAngle;

            //If we have any leftover roller path, account for it here to keep spacing consistent.
            //We may also have leftover straight path length if we didn't do anything on a roller.
            //If we have roller length, make sure to offset it to account for the curvature of the roller.
            //If we don't do this, the line won't start at the end of the prior roller.
            //If we are on the last roller, we need to get the first roller to complete the loop.
            //For points that start and end at an angle of around 0 (top of rollers) we add droop.
            TreadRoller nextRoller = i == rollers.size() - 1 ? rollers.get(0) : rollers.get(i + 1);
            double straightPathLength = Math.hypot(nextRoller.startY - roller.endY, nextRoller.startZ - roller.endZ);
            double extraPathLength = rollerPathLength + leftoverPathLength;
            if (tread.placementDefinition.treadDroopConstant > 0 && (roller.endAngle % 360 < 10 || roller.endAngle % 360 > 350) && (nextRoller.startAngle % 360 < 10 || nextRoller.startAngle % 360 > 350)) {
                //Catenary path length is a*singh(x/a), a is droop constant, x will be 1/2 total catenary distance due to symmetry, multiply this distance by 2 for total droop.
                double catenaryPathLength = 2D * tread.placementDefinition.treadDroopConstant * Math.sinh((straightPathLength / 2D) / tread.placementDefinition.treadDroopConstant);

                //Get the top point in Y for the tips of the catenary (1/2 the span).  We will translate the droop path down this far to make the ends line up at Y=0.
                //We then offset this value to the rollers for the actual point position.
                final double catenaryPathEdgeY = tread.placementDefinition.treadDroopConstant * Math.cosh((straightPathLength / 2D) / tread.placementDefinition.treadDroopConstant);

                double catenaryFunctionCurrent = -catenaryPathLength / 2F;
                double catenaryPointZ;
                double catenaryPointY;
                double startingCatenaryPathLength = catenaryPathLength;
                double yDelta = nextRoller.startY - roller.endY;
                while (catenaryPathLength + extraPathLength > deltaDist) {
                    //Go to and add the next point on the catenary path.
                    if (extraPathLength > 0) {
                        catenaryFunctionCurrent += (deltaDist - extraPathLength);
                        catenaryPathLength -= (deltaDist - extraPathLength);
                        extraPathLength = 0;
                    } else {
                        catenaryFunctionCurrent += deltaDist;
                        catenaryPathLength -= deltaDist;
                    }
                    double value = catenaryFunctionCurrent / tread.placementDefinition.treadDroopConstant;
                    double arcSin = catenaryFunctionCurrent == 0.0 ? 0 : Math.log(value + Math.sqrt(value * value + 1.0));
                    double catenaryFunctionPercent = (catenaryFunctionCurrent + startingCatenaryPathLength / 2) / startingCatenaryPathLength;
                    catenaryPointZ = tread.placementDefinition.treadDroopConstant * arcSin;
                    catenaryPointY = tread.placementDefinition.treadDroopConstant * Math.cosh(catenaryPointZ / tread.placementDefinition.treadDroopConstant);
                    yPoint = roller.endY + yDelta * catenaryFunctionPercent + catenaryPointY - catenaryPathEdgeY;
                    zPoint = roller.endZ + catenaryPointZ + straightPathLength / 2D;
                    points.add(new Double[]{yPoint, zPoint, currentAngle + 180 - Math.toDegrees(Math.asin(catenaryFunctionCurrent / tread.placementDefinition.treadDroopConstant))});
                }
                leftoverPathLength = catenaryPathLength;
            } else {
                double normalizedY = (nextRoller.startY - roller.endY) / straightPathLength;
                double normalizedZ = (nextRoller.startZ - roller.endZ) / straightPathLength;
                while (straightPathLength + extraPathLength > deltaDist) {
                    //Go to and add the next point on the straight path.
                    if (extraPathLength > 0) {
                        yPoint = roller.endY + normalizedY * (deltaDist - extraPathLength);
                        zPoint = roller.endZ + normalizedZ * (deltaDist - extraPathLength);
                        straightPathLength -= (deltaDist - extraPathLength);
                        extraPathLength = 0;
                    } else {
                        yPoint += normalizedY * deltaDist;
                        zPoint += normalizedZ * deltaDist;
                        straightPathLength -= deltaDist;
                    }
                    points.add(new Double[]{yPoint, zPoint, currentAngle + 180});
                }
                leftoverPathLength = straightPathLength;
            }
        }
        return points;
    }

    /**
     * Resolves convenient pack-relative names while retaining support for full cross-pack paths.
     */
    public static String resolveOverlayTexture(AJSONMultiModelProvider definition, String texture) {
        if (texture == null || texture.startsWith("/") || texture.contains(":")) {
            return texture;
        }
        String textureName = texture.endsWith(".png") ? texture.substring(0, texture.length() - ".png".length()) : texture;
        return PackResourceLoader.getPackResource(definition, ResourceType.PNG, textureName);
    }

    /**
     * Gets PNG dimensions for converting pixel positions to normalized UV offsets.  Successful
     * reads are cached across entities; failed reads are retried after future model resets so
     * resource hotloading can recover without restarting the game.
     */
    public static synchronized int[] getTextureDimensions(String texture) {
        int[] cachedDimensions = textureDimensions.get(texture);
        if (cachedDimensions != null) {
            return cachedDimensions;
        }

        String resourceLocation = texture;
        if (resourceLocation != null && resourceLocation.contains(":")) {
            resourceLocation = "/assets/" + resourceLocation.replace(':', '/');
        }
        if (resourceLocation != null) {
            try (InputStream textureStream = InterfaceManager.renderingInterface.getTextureStream(resourceLocation)) {
                if (textureStream != null) {
                    try (ImageInputStream imageStream = ImageIO.createImageInputStream(textureStream)) {
                        Iterator<ImageReader> readers = ImageIO.getImageReaders(imageStream);
                        if (readers.hasNext()) {
                            ImageReader reader = readers.next();
                            try {
                                reader.setInput(imageStream, true, true);
                                int width = reader.getWidth(0);
                                int height = reader.getHeight(0);
                                if (width > 0 && height > 0) {
                                    int[] dimensions = new int[] {width, height};
                                    textureDimensions.put(texture, dimensions);
                                    invalidTextureDimensions.remove(texture);
                                    return dimensions;
                                }
                            } finally {
                                reader.dispose();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                //The renderer will substitute its normal missing texture below.  Log only once here
                //to explain why pixel-based movement cannot be normalized for this resource.
            }
        }

        if (invalidTextureDimensions.add(String.valueOf(texture))) {
            InterfaceManager.coreInterface.logError("Could not read texture overlay dimensions for: " + texture + ". Pixel offsets will use a 1x1 fallback until the model is reloaded.");
        }
        return new int[] {1, 1};
    }

    /**Clears resource-derived overlay state when packs are hotloaded.**/
    public static synchronized void clearTextureOverlayCaches() {
        textureDimensions.clear();
        invalidTextureDimensions.clear();
        windowVertexObjects.clear();
        textureOverlayVertexObjects.clear();
    }

    /**Returns full-texture window vertices without altering the model parser's shared UV data.**/
    private static synchronized RenderableVertices getWindowVertexObject(RenderableVertices source) {
        RenderableVertices cachedObject = windowVertexObjects.get(source);
        if (cachedObject == null) {
            FloatBuffer sourceData = source.vertices.duplicate();
            sourceData.rewind();
            FloatBuffer copiedData = FloatBuffer.allocate(source.vertices.capacity());
            copiedData.put(sourceData);
            copiedData.flip();
            cachedObject = new RenderableVertices(source.name, copiedData, source.cacheVertices, source.isErrorPlaceholder);
            cachedObject.setTextureBounds(0, 1, 0, 1);
            windowVertexObjects.put(source, cachedObject);
        }
        return cachedObject;
    }

    /**Returns standalone-texture UVs for atlas-backed models, sharing the copy across entities.*/
    public static synchronized RenderableVertices getTextureOverlayVertexObject(RenderableVertices source) {
        RenderableVertices cachedObject = textureOverlayVertexObjects.get(source);
        if (cachedObject == null) {
            cachedObject = source.createTextureNormalizedCopy();
            if (cachedObject != source) {
                textureOverlayVertexObjects.put(source, cachedObject);
            }
        }
        return cachedObject;
    }

    private static class TextureOverlayRenderable {
        private final RenderableData renderable;
        private final RenderableData interiorRenderable;
        private final int textureWidth;
        private final int textureHeight;

        private TextureOverlayRenderable(RenderableData renderable, RenderableData interiorRenderable, int textureWidth, int textureHeight) {
            this.renderable = renderable;
            this.interiorRenderable = interiorRenderable;
            this.textureWidth = textureWidth;
            this.textureHeight = textureHeight;
        }
    }

    /**
     * Custom URL downloader class to prevent blocking of the main thread when downloading textures
     * and to give more time for the downloader to run.
     *
     * @author don_bruce
     */
    private static class ConnectorThread extends Thread {
        private final String urlString;

        public ConnectorThread(String urlString) {
            this.urlString = urlString;
        }

        @Override
        public void run() {
            //Parse the texture out into an InputStream, if possible, and bind it.
            //FAR less jank than using MC's resource system.
            //We try a few times here since sources can do dumb things.
            int tryCount = 0;
            String errorString = null;
            do {
                try {
                    URL urlObject = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) urlObject.openConnection();
                    try {
                        connection.connect();
                        String contentType = connection.getContentType();
                        String[] typeParams = contentType.split("/");
                        if (typeParams[0].equals("text")) {
                            errorString = "ERROR: Found only text at the URL.  This is not a direct image link, or you don't have permission to view this image (hosted behind a login).";
                        } else {
                            Iterator<ImageReader> iterator = ImageIO.getImageReadersByFormatName(typeParams[1]);
                            if (iterator.hasNext()) {
                                ImageReader reader = iterator.next();
                                if (typeParams[1].equals("gif")) {
                                    ImageInputStream stream = ImageIO.createImageInputStream(connection.getInputStream());
                                    reader.setInput(stream);
                                    ParsedGIF gif = GIFParser.parseGIF(reader);
                                    if (gif != null) {
                                        if (InterfaceManager.renderingInterface.bindURLGIF(urlString, gif)) {
                                            downloadedTextures.add(urlString);
                                            downloadingTextures.remove(urlString);
                                            return;
                                        } else {
                                            errorString = "ERROR: Could not parse GIF due to an internal MC-system interface error.  Contact the mod author!";
                                        }
                                    } else {
                                        errorString = "ERROR: Could not parse GIF due to no frames being present.  Is this a real direct link or a fake one?";
                                    }
                                } else {
                                    if (InterfaceManager.renderingInterface.bindURLTexture(urlString, connection.getInputStream())) {
                                        downloadedTextures.add(urlString);
                                        downloadingTextures.remove(urlString);
                                        return;
                                    } else {
                                        errorString = "ERROR: Got a correct image type, but was missing data for the image?  Likely partial data sent by the server source, try again later.";
                                    }
                                }
                            } else {
                                errorString = "ERROR: Invalid content type found.  Found:" + contentType + ", but the only valid types are: ";
                                for (String imageSuffix : ImageIO.getReaderFileSuffixes()) {
                                    errorString += ("image/" + imageSuffix + ", ");
                                }
                            }
                        }
                    } catch (Exception e) {
                        errorString = "ERROR: Could not parse images.  Error was: " + e.getMessage();
                    }
                } catch (Exception e) {
                    errorString = "ERROR: Could not open URL for processing.  Error was: " + e.getMessage();
                }
            } while (++tryCount < 10);

            //Set missing texture if we failed to get anything.
            InterfaceManager.renderingInterface.bindURLTexture(urlString, null);
            erroredTextures.put(urlString, errorString);
            downloadingTextures.remove(urlString);
            downloadedTextures.add(urlString);
        }
    }
}
