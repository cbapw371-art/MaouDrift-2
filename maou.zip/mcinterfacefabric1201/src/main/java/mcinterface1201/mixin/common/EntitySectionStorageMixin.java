package mcinterface1201.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import mcinterface1201.BuilderEntityExisting;
import net.minecraft.world.level.entity.EntitySectionStorage;

/**
 * Forge patches Level to track the max entity radius so big vehicles are found by entity searches.
 * Vanilla hardcodes 2.0 blocks in the section search, so we widen it to the largest vehicle seen.
 * require = 0 so a mismatch only skips this tweak instead of crashing the game.
 */
@Mixin(EntitySectionStorage.class)
public abstract class EntitySectionStorageMixin {
    @ModifyConstant(method = "forEachAccessibleNonEmptySection", constant = @Constant(doubleValue = 2.0D), require = 0)
    private double iv_maxEntityRadius(double original) {
        return Math.max(original, BuilderEntityExisting.MAX_ENTITY_RADIUS_SEEN);
    }
}
