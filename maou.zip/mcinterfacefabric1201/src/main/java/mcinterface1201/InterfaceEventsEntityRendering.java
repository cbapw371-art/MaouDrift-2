package mcinterface1201;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.vertex.PoseStack;

import mcinterface1201.mixin.client.CameraMixin;
import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.baseclasses.RotationMatrix;
import minecrafttransportsimulator.entities.components.AEntityB_Existing;
import minecrafttransportsimulator.entities.instances.EntityPlayerGun;
import minecrafttransportsimulator.entities.instances.PartSeat;
import minecrafttransportsimulator.mcinterface.IWrapperPlayer;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.rendering.dynamiclight.DynamicLightShadowAtlas;
import minecrafttransportsimulator.rendering.dynamiclight.DynamicLightSystem;
import minecrafttransportsimulator.systems.CameraSystem;
import minecrafttransportsimulator.systems.CameraSystem.CameraMode;
import minecrafttransportsimulator.systems.ConfigSystem;
import com.mojang.math.Axis;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Camera;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

/**
 * Interface for handling events pertaining to entity rendering.  This modifies the player's rendered state
 * to handle them being in vehicles, as well as ensuring their model adapts to any objects they may be holding.
 * This also handles the 2D GUI rendering.
 *
 * @author don_bruce
 */
public class InterfaceEventsEntityRendering {
    public static final Point3D cameraAdjustedPosition = new Point3D();
    public static final RotationMatrix cameraAdjustedOrientation = new RotationMatrix();
    private static final RotationMatrix cameraShakeRotation = new RotationMatrix();
    public static final RotationMatrix cameraShakeProjectionRotation = new RotationMatrix();
    public static boolean adjustedCamera;
    public static boolean cameraShakeActive;
    private static Player mcPlayer;

    private static int lastScreenWidth;
    private static int lastScreenHeight;
    /**
     * Registers Fabric callbacks.  Camera, overlay-blocking, hand, arm, and name-tag handling are done
     * by mixins (GameRendererMixin, GuiMixin, ItemInHandRendererMixin, PlayerRendererMixin, EntityRendererMixin)
     * which call the static methods in this class.
     */
    public static void registerClientEvents() {
        HudRenderCallback.EVENT.register(InterfaceEventsEntityRendering::onIVRenderOverlay);
        //A chunk arrived on the client: the dynamic light block grid reads its sections again.
        ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> DynamicLightSystem.markColumn(chunk.getPos().x, chunk.getPos().z));
    }

    /**
     * Changes camera rotation to match custom rotation, and also gets custom position for custom cameras.
     * Replaces Forge's ViewportEvent.ComputeCameraAngles.  Called from GameRendererMixin right after the camera
     * has been set up (before the camera rotation is applied to the pose stack).
     */
    public static void onIVCameraSetup(Camera camera, float partialTicks, PoseStack poseStack) {
        cameraShakeActive = false;
        if (camera.getEntity() instanceof Player) {
            mcPlayer = (Player) camera.getEntity();
            IWrapperPlayer player = WrapperPlayer.getWrapperFor(mcPlayer);
            cameraAdjustedPosition.set(0, 0, 0);
            cameraAdjustedOrientation.setToZero();
            adjustedCamera = false;
            //Same initial values as Forge's ComputeCameraAngles event.
            float yaw = camera.getYRot();
            float pitch = camera.getXRot();
            float roll = 0;
            boolean anglesChanged = false;
            if (CameraSystem.adjustCamera(player, cameraAdjustedPosition, cameraAdjustedOrientation, partialTicks)) {
                //Camera adjustments occur backwards here.  Reverse order in the matrix.
                //Also need to reverse sign of Y, since that's backwards in MC.
                cameraAdjustedOrientation.convertToAngles();
                if (InterfaceManager.clientInterface.getCameraMode() == CameraMode.THIRD_PERSON_INVERTED) {
                    //Inverted third-person needs roll and pitch flipped due to the opposite perspective.
                    //It also needs the camera rotated 180 in the Y to face the other direction.
                    roll = (float) -cameraAdjustedOrientation.angles.z;
                    pitch = (float) -cameraAdjustedOrientation.angles.x;
                    yaw = (float) (-cameraAdjustedOrientation.angles.y + 180);
                } else {
                    roll = (float) cameraAdjustedOrientation.angles.z;
                    pitch = (float) cameraAdjustedOrientation.angles.x;
                    yaw = (float) -cameraAdjustedOrientation.angles.y;
                }
                //Move the info's setup to the set position of the camera.
                //This will offset the player's eye position to match the camera.
                //We do this in first-person mode since third-person adds zoom stuff.
                ((CameraMixin) camera).invoke_setPosition(cameraAdjustedPosition.x, cameraAdjustedPosition.y, cameraAdjustedPosition.z);
                adjustedCamera = true;
                anglesChanged = true;
            }
            cameraShakeRotation.setToZero();
            cameraShakeActive = CameraSystem.applyCameraShake(cameraShakeRotation);
            if (cameraShakeActive) {
                cameraShakeRotation.convertToAngles();
                if (InterfaceManager.clientInterface.getCameraMode() == CameraMode.THIRD_PERSON_INVERTED) {
                    roll = (float) (roll - cameraShakeRotation.angles.z);
                    pitch = (float) (pitch - cameraShakeRotation.angles.x);
                } else {
                    roll = (float) (roll + cameraShakeRotation.angles.z);
                    pitch = (float) (pitch + cameraShakeRotation.angles.x);
                }
                yaw = (float) (yaw - cameraShakeRotation.angles.y);
                cameraShakeProjectionRotation.angles.set(pitch, -yaw, roll);
                cameraShakeProjectionRotation.updateToAngles();
                anglesChanged = true;
            }
            if (anglesChanged) {
                //Apply what Forge did with the event result: set camera angles, then apply roll to the pose stack.
                ((CameraMixin) camera).invoke_setRotation(yaw, pitch);
                poseStack.mulPose(Axis.ZP.rotationDegrees(roll));
            }
        }
    }

    /**
     * Replaces Forge's RenderGuiOverlayEvent.Pre for the crosshair.
     */
    public static boolean shouldCancelCrosshair() {
        //If we are rendering the custom camera overlay, block the crosshairs.
        return CameraSystem.customCameraOverlay != null;
    }

    /**
     * Replaces Forge's RenderGuiOverlayEvent.Pre for the hotbar.
     */
    public static boolean shouldCancelHotbar() {
        //If we are rendering the custom camera overlay, block the hotbar.
        return CameraSystem.customCameraOverlay != null || shouldCancelStatusOverlay();
    }

    /**
     * Replaces Forge's RenderGuiOverlayEvent.Pre for food, health, armor, and experience.
     * If we are seated in a controller seat, and are rendering GUIs, disable the vanilla HUD.
     */
    public static boolean shouldCancelStatusOverlay() {
        if (InterfaceManager.clientInterface == null) {
            return false;
        }
        if (InterfaceManager.clientInterface.getCameraMode() == CameraMode.FIRST_PERSON ? ConfigSystem.client.renderingSettings.renderHUD_1P.value : ConfigSystem.client.renderingSettings.renderHUD_3P.value) {
            IWrapperPlayer player = InterfaceManager.clientInterface.getClientPlayer();
            if (player != null) {
                AEntityB_Existing ridingEntity = player.getEntityRiding();
                return ridingEntity instanceof PartSeat && ((PartSeat) ridingEntity).placementDefinition.isController;
            }
        }
        return false;
    }

    /**
     * Renders all overlay things.  This is essentially anything that's a 2D render, such as the main overlay,
     * vehicle HUds, GUIs, camera overlays, etc.
     */
    private static void onIVRenderOverlay(GuiGraphics guiGraphics, float partialTicks) {
        if (Minecraft.getInstance().options.hideGui) {
            return;
        }
        Window window = Minecraft.getInstance().getWindow();
        long displaySize = InterfaceManager.clientInterface.getPackedDisplaySize();
        int screenWidth = (int) (displaySize >> Integer.SIZE);
        int screenHeight = (int) displaySize;
        double[] xPos = new double[1];
        double[] yPos = new double[1];
        GLFW.glfwGetCursorPos(window.getWindow(), xPos, yPos);
        int mouseX = (int) (xPos[0] * screenWidth / window.getScreenWidth());
        int mouseY = (int) (yPos[0] * screenHeight / window.getScreenHeight());

        boolean updateGUIs = screenWidth != lastScreenWidth || screenHeight != lastScreenHeight;
        if (updateGUIs) {
            lastScreenWidth = screenWidth;
            lastScreenHeight = screenHeight;
        }

        InterfaceRender.renderGUI(guiGraphics, mouseX, mouseY, screenWidth, screenHeight, partialTicks, updateGUIs);
    }

    /**
     * No name tag inside a dynamic light shadow tile.  Called from EntityRendererMixin.
     */
    public static boolean shouldCancelNameTag() {
        return DynamicLightShadowAtlas.isRendering();
    }

    /**
     * Hand and arm render events.  We use these to disable rendering of the item in the player's hand
     * if they are holding a gun.  Called from ItemInHandRendererMixin and PlayerRendererMixin.
     */
    public static boolean shouldCancelHandRender() {
        if (Minecraft.getInstance().player == null) {
            return false;
        }
        EntityPlayerGun entity = EntityPlayerGun.playerClientGuns.get(Minecraft.getInstance().player.getUUID());
        return (entity != null && entity.activeGun != null) || CameraSystem.activeCamera != null;
    }
}
