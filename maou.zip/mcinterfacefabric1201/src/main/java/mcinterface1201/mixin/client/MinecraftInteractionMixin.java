package mcinterface1201.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import mcinterface1201.InterfaceInput;
import net.minecraft.client.Minecraft;

/**Pengganti InputEvent.InteractionKeyMappingTriggered (Forge): klik kiri/kanan vanilla bisa dibatalkan.*/
@Mixin(Minecraft.class)
public abstract class MinecraftInteractionMixin {
    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true)
    private void iv_onStartAttack(CallbackInfoReturnable<Boolean> cir) {
        if (InterfaceInput.shouldCancelInteraction(false)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "startUseItem", at = @At("HEAD"), cancellable = true)
    private void iv_onStartUseItem(CallbackInfo ci) {
        if (InterfaceInput.shouldCancelInteraction(true)) {
            ci.cancel();
        }
    }
}
