package minecrafttransportsimulator.jsondefs;

import java.util.HashMap;
import java.util.Map;

import minecrafttransportsimulator.entities.instances.EntityVehicleF_Physics;

/**
 * Config class for client settings.  This is only loaded on the client.  This allows the
 * server to send over its config data, but the client-side stuff gets left alone.
 *
 * @author don_bruce
 */
public class JSONConfigClient {
    public JSONRenderingSettings renderingSettings = new JSONRenderingSettings();
    public JSONControlSettings controlSettings = new JSONControlSettings();
    public JSONControls controls = new JSONControls();

    public static class JSONRenderingSettings {
        public JSONConfigEntry<Boolean> renderHUD_1P = new JSONConfigEntry<>(true, "If false, the HUD in vehicles will not render in 1st-person mode.");
        public JSONConfigEntry<Boolean> renderHUD_3P = new JSONConfigEntry<>(true, "If false, the HUD in vehicles will not render in 3rd-person mode.");

        public JSONConfigEntry<Boolean> fullHUD_1P = new JSONConfigEntry<>(false, "If true, the full-size HUD will render in 1st-person rather than the half-size HUD.");
        public JSONConfigEntry<Boolean> fullHUD_3P = new JSONConfigEntry<>(false, "If true, the full-size HUD will render in 3rd-person rather than the half-size HUD.");

        public JSONConfigEntry<Boolean> transpHUD_1P = new JSONConfigEntry<>(true, "If true, the background textures for the HUD will not be rendered in 1st-person.");
        public JSONConfigEntry<Boolean> transpHUD_3P = new JSONConfigEntry<>(true, "If true, the background textures for the HUD will not be rendered in 3rd-person.");

        public JSONConfigEntry<Boolean> renderWindows = new JSONConfigEntry<>(true, "Should the glass on windows be rendered on vehicles?");
        public JSONConfigEntry<Boolean> innerWindows = new JSONConfigEntry<>(false, "Should the glass on windows be rendered on the inside of the vehicle?  Note: if renderWindows is false, this config has no effect.");
        public JSONConfigEntry<Boolean> freecam_3P = new JSONConfigEntry<>(false, "If true, third-person camera rotation in vehicles is disconnected from vehicle rotation and uses only rider look rotation.");
        
        public JSONConfigEntry<Boolean> renderFlares = new JSONConfigEntry<>(true, "If false, flares on lights will not render.");
        public JSONConfigEntry<Boolean> renderBeams = new JSONConfigEntry<>(true, "If false, beams on lights will not render.");

        public JSONConfigEntry<Boolean> dynamicLights = new JSONConfigEntry<>(true, "If true, light components marked isDynamicLight light up the world around them, cast shadows and draw a volumetric beam and corona.  If false, they render as regular beams and flares.");
        public JSONConfigEntry<Boolean> DynL_shadows = new JSONConfigEntry<>(true, "If true, dynamic lights cast shadows from blocks, vehicles and mobs.  Turn off to save GPU time.");
        public JSONConfigEntry<Integer> DynL_MaxLights = new JSONConfigEntry<>(48, "How many dynamic lights may light the world at once, 0 to 256, and how many beams and coronas are drawn.  The strongest and closest are kept.  Fewer lights cost less GPU time; raise it on a powerful machine.");
        public JSONConfigEntry<Boolean> DynL_ShaderFB = new JSONConfigEntry<>(false, "If true, dynamic lights still light the world under a shader pack (Iris, Oculus, OptiFine) by raising block light and drawing a simple beam cone and flare.  If false, they render as regular beams and flares while a shader pack is active.");

        public JSONConfigEntry<Boolean> brightLights = new JSONConfigEntry<>(true, "If false, lights from vehicles and blocks will not make themselves bright and instead will render as if they were part of the model at that same brightness.  Useful if you have shaders and this is causing troubles.");
        public JSONConfigEntry<Boolean> blendedLights = new JSONConfigEntry<>(true, "If false, beam-based lights from vehicles and blocks will not do brightness blending.  This is different from the general brightness setting as this will do OpenGL blending on the world to make it brighter, not just the beams themselves.");

        public JSONConfigEntry<Boolean> lightsTransp = new JSONConfigEntry<>(false, "If true, textures that light up will be rendered on the transperent pass.  This is required for some shaders to prevent lit textures without alpha channels from becoming invible, but it may break rendering on non-shader builds.");
        public JSONConfigEntry<Boolean> playerTweaks = new JSONConfigEntry<>(true, "If true, player hands will be modified when holding guns, and hands and legs will be modified when riding in vehicles.  Set this to false (and restart the game) if mods cause issues, like two-hand rendering or player model issues.  Automatically set to false if some mods are detected.");
        public JSONConfigEntry<Boolean> gunCrosshair = new JSONConfigEntry<>(true, "If false, the aiming crosshair for active guns will not be rendered.");
        public JSONConfigEntry<Boolean> customInventoryTabs = new JSONConfigEntry<>(true, "If false, pack-authored creative-inventory side tabs are disabled and every pack item is shown together in the normal pack tab.  Disable this if another mod's creative inventory is incompatible with the side-tab UI.");

        public JSONConfigEntry<Integer> renderingMode = new JSONConfigEntry<>(0, "Internal rendering mode value, don't touch!");
    }

    public static class JSONControlSettings {
        public JSONConfigEntry<Boolean> kbOverride = new JSONConfigEntry<>(true, "Should keyboard controls be ignored when a joystick control is mapped?  Leave true to free up the keyboard while using a joysick.");
        public JSONConfigEntry<Boolean> north360 = new JSONConfigEntry<>(false, "If true, instruments will represent North as 360 degrees, instead of the Minecraft default of 180. Allows using the heading system that real-world pilots and militaries do.");

        public JSONConfigEntry<Boolean> simpleThrottle = new JSONConfigEntry<>(true, "If true, ground vehicles use simplified driving controls: gas/brake also handle forward and reverse shifting when stopped, the vehicle auto-holds the brake at low speed, and transmissions shift automatically while driving.");
        public JSONConfigEntry<Boolean> halfThrottle = new JSONConfigEntry<>(false, "If true, then the gas key will only be a half-throttle, with the MOD+Throttle key becoming the full-speed control.  Useful if you want a more controlled vehicle experience.  Only valid on car/boat types with on-off throttles, and does not work in conjunction with simpleThrottle as that changes how the MOD key works with gas and brake keys.");

        public JSONConfigEntry<Boolean> autostartEng = new JSONConfigEntry<>(true, "If true, engines will automatically start when a driver enters a vehicle, and will turn off when they leave.  The parking brake will also be applied when leaving the vehicle.  Note: this does not bypass the fuel or electrical system.");
        public JSONConfigEntry<Boolean> autoTrnSignals = new JSONConfigEntry<>(true, "If true, turns signals will come on automatically when you start a turn, and will turn off when the turn completes.  If this is false, then they will only be able to be activated with the keybinds or via the panel.");

        public JSONConfigEntry<Boolean> useShifter = new JSONConfigEntry<>(false, "Set to true if you are using a real life physical shifter controller for shifting gears.  Required since IV doesn't know this automatically since a shifter in neutral won't press any buttons.");
        public JSONConfigEntry<Boolean> heliAutoLevel = new JSONConfigEntry<>(false, "If true, helicopters will automatically return to level flight when you let off the control stick.  However, this will prevent them from doing loops.  The realistic value for this config is false, but the one that's more player-freindly is true.");
        public JSONConfigEntry<Boolean> mouseYoke = new JSONConfigEntry<>(false, "If true, aircraft pitch and roll are controlled by an invisible on-screen mouse yoke.  Cursor center is neutral; window edges are full input.");
        public JSONConfigEntry<Boolean> arcadeMode = new JSONConfigEntry<>(false, "If true, arcade-style flight and mouse aiming will be enabled. This allows the mouse cursor to control aircraft/helicopter steering systems.");
        public JSONConfigEntry<Boolean> showTutorial = new JSONConfigEntry<>(true, "If true, tutorial and onboarding overlays may be shown.  Set this to false to hide those prompts.");
        public JSONConfigEntry<Boolean> showDefaultAircraftControlsMessageEveryTime = new JSONConfigEntry<>(true, "If true, the message telling you which controls an aircraft defaults to will show every time you get into the pilot seat of an aircraft that sets its own default.  If false, it only shows the first time you fly each aircraft in each mode.");
        public JSONConfigEntry<Boolean> showHoverTxt = new JSONConfigEntry<>(true, "If true, hover text helpers may be shown when looking at supported vehicle elements.  Set this to false to hide those prompts.");
        public JSONConfigEntry<Boolean> cullingWarn = new JSONConfigEntry<>(true, "If true, IV will show a one-time startup warning when Entity Culling is detected.");

        public JSONConfigEntry<Boolean> classicJystk = new JSONConfigEntry<>(false, "If true, the classic controller code will be used.  Note: THIS CODE MAY CRASH MOBILE DEVICES!  Also note that switching will probably mess up your keybinds.  Only do this if you are having issues with a joystick or controller not being recognized.  After changing this setting, reboot the game to make it take effect.");



        public JSONConfigEntry<Double> steeringControlRate = new JSONConfigEntry<>(EntityVehicleF_Physics.RUDDER_DAMPEN_RATE, "How many degrees to turn the wheels on vehicles for every tick the button is held down.  This is not used when using a joystick.");
        public JSONConfigEntry<Double> steeringReturnRate = new JSONConfigEntry<>(EntityVehicleF_Physics.RUDDER_DAMPEN_RETURN_RATE, "How many degrees to turn the wheels on vehicles for every tick the button is NOT held down.  This is not used when using a joystick.");
        public JSONConfigEntry<Double> flightControlRate = new JSONConfigEntry<>(EntityVehicleF_Physics.AILERON_DAMPEN_RATE, "How many degrees to move the elevators and ailerons on aircraft for every tick the button is held down.  This is not used when using a joystick.");
        public JSONConfigEntry<Double> mouseYokeRate = new JSONConfigEntry<>(0.1D, "How many degrees to move control surfaces for every 1 mouse unit change.  Used for mouse yoke controls.");
        public JSONConfigEntry<Double> DismountSafteySpeed = new JSONConfigEntry<>(8.0D, "Speed, in m/s, above which vehicle dismounting requires pressing Shift twice within 3 seconds.  Set to 0 to always prompt, or a very high value to effectively keep classic instant dismounts.");
        public JSONConfigEntry<Double> joystickDeadZone = new JSONConfigEntry<>(0.03D, "Dead zone for joystick axis.  This is NOT joystick specific.");
        public JSONConfigEntry<Float> soundVolume = new JSONConfigEntry<>(1.0F, "Volume for all sounds in the mod.  This is used instead of the game's master volume.");
        public JSONConfigEntry<Float> radioVolume = new JSONConfigEntry<>(1.0F, "Volume for radios in the mod.  This is used instead of the game's master volume.");

        //Per-aircraft arcade flight choices for aircraft that set arcadeFlightMode, set with the arcade key.
        //Keyed by "packID:systemName|arcade" or "packID:systemName|standard" (the default being overridden).
        //True is arcade flight, false is standard controls.  May be null if loaded from an older config.
        public Map<String, Boolean> arcadeFlightOverrides = new HashMap<>();
    }

    public static class JSONControls {
        public int keysetID;
        public Map<String, ConfigKeyboard> keyboard = new HashMap<>();
        public Map<String, ConfigJoystick> joystick = new HashMap<>();
    }

    public static class ConfigKeyboard {
        public int keyCode;
        public boolean isMouseButton;
    }

    public static class ConfigJoystick {
        public String joystickName;
        public int buttonIndex;
        public boolean invertedAxis;
        public double axisMinTravel;
        public double axisMaxTravel;
    }
}
