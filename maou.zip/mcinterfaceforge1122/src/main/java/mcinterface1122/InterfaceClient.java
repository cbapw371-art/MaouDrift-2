package mcinterface1122;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.entities.components.AEntityD_Definable;
import minecrafttransportsimulator.guis.components.AGUIBase;
import minecrafttransportsimulator.guis.instances.GUIPackMissing;
import minecrafttransportsimulator.entities.instances.EntityInventoryContainer;
import minecrafttransportsimulator.mcinterface.AWrapperWorld;
import minecrafttransportsimulator.mcinterface.IInterfaceClient;
import minecrafttransportsimulator.mcinterface.IWrapperItemStack;
import minecrafttransportsimulator.mcinterface.IWrapperNBT;
import minecrafttransportsimulator.mcinterface.IWrapperPlayer;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.packloading.PackParser;
import minecrafttransportsimulator.rendering.RenderableModelObject;
import minecrafttransportsimulator.systems.CameraSystem.CameraMode;
import minecrafttransportsimulator.systems.ConfigSystem;
import minecrafttransportsimulator.systems.ControlSystem;
import net.minecraft.block.SoundType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.resources.IReloadableResourceManager;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.relauncher.Side;

@EventBusSubscriber(Side.CLIENT)
public class InterfaceClient implements IInterfaceClient {
    private static CameraMode actualCameraMode;
    private static CameraMode cameraModeRequest;
    private static int ticksToCullingWarning = 200;
    private static BuilderEntityRenderForwarder activeFollower;
    private static int ticksSincePlayerJoin;

    public static void registerResourceReloadListener() {
        //Rebuild overlay renderables after F3+T so changed PNG dimensions and UV caches
        //cannot survive a resource reload.  The implementation belongs in this client-only
        //class so dedicated servers never load Minecraft client classes from the common loader.
        ((IReloadableResourceManager) Minecraft.getMinecraft().getResourceManager()).registerReloadListener(resourceManager -> {
            RenderableModelObject.clearTextureOverlayCaches();
            AWrapperWorld world = InterfaceManager.clientInterface.getClientWorld();
            if (world != null) {
                for (AEntityD_Definable<?> entity : world.getEntitiesExtendingType(AEntityD_Definable.class)) {
                    entity.resetModelsAndAnimations();
                }
            }
        });
    }

    @Override
    public boolean isGamePaused() {
        return Minecraft.getMinecraft().isGamePaused();
    }

    @Override
    public String getLanguageName() {
        return Minecraft.getMinecraft().gameSettings.language;
    }

    @Override
    public List<String> getAllLanguages() {
        List<String> list = new ArrayList<>();
        Minecraft.getMinecraft().getLanguageManager().getLanguages().forEach(language -> list.add(language.getLanguageCode()));
        return list;
    }

    @Override
    public String getFluidName(String fluidID, String fluidMod) {
        Fluid fluid = FluidRegistry.getFluid(fluidID);
        return fluid != null ? new FluidStack(fluid, 1).getLocalizedName() : "INVALID";
    }

    @Override
    public Map<String, String> getAllFluidNames() {
        Map<String, String> fluidIDsToNames = new HashMap<>();
        for (String fluidID : FluidRegistry.getRegisteredFluids().keySet()) {
            fluidIDsToNames.put(fluidID, new FluidStack(FluidRegistry.getFluid(fluidID), 1).getLocalizedName());
        }
        return fluidIDsToNames;
    }

    @Override
    public boolean isChatOpen() {
        return Minecraft.getMinecraft().ingameGUI.getChatGUI().getChatOpen();
    }

    @Override
    public boolean isGUIOpen() {
        return Minecraft.getMinecraft().currentScreen != null;
    }

    @Override
    public void displayOverlayMessage(String message) {
        Minecraft.getMinecraft().ingameGUI.setOverlayMessage(message, false);
    }

    @Override
    public CameraMode getCameraMode() {
        return actualCameraMode;
    }

    @Override
    public void setCameraMode(CameraMode mode) {
        cameraModeRequest = mode;
    }

    @Override
    public int getCameraDefaultZoom() {
        return 4;
    }

    @Override
    public long getPackedDisplaySize() {
        ScaledResolution screenResolution = new ScaledResolution(Minecraft.getMinecraft());
        return (((long) screenResolution.getScaledWidth()) << Integer.SIZE) | (screenResolution.getScaledHeight() & 0xffffffffL);
    }

    @Override
    public float getMouseSensitivity() {
        return Minecraft.getMinecraft().gameSettings.mouseSensitivity;
    }

    @Override
    public void setMouseSensitivity(float setting) {
        Minecraft.getMinecraft().gameSettings.mouseSensitivity = setting;
    }

    @Override
    public float getFOV() {
        return Minecraft.getMinecraft().gameSettings.fovSetting;
    }

    @Override
    public void setFOV(float setting) {
        Minecraft.getMinecraft().gameSettings.fovSetting = setting;
    }

    @Override
    public boolean isGUIHidden() {
        return Minecraft.getMinecraft().gameSettings.hideGUI;
    }

    @Override
    public void closeGUI() {
        Minecraft.getMinecraft().displayGuiScreen(null);
    }

    @Override
    public void setActiveGUI(AGUIBase gui) {
        FMLCommonHandler.instance().showGuiScreen(new BuilderGUI(gui));
    }

    public void openInventoryGUI(IWrapperNBT inventoryData, int inventorySize, int stackSize, String texture, int heldPlayerSlot, int windowID) {
        Minecraft minecraft = Minecraft.getMinecraft();
        WrapperWorld world = WrapperWorld.getWrapperFor(minecraft.world);
        EntityInventoryContainer inventory = new EntityInventoryContainer(world, inventoryData, inventorySize, stackSize);
        BuilderInventoryContainerMenu menu = new BuilderInventoryContainerMenu(minecraft.player.inventory, inventory, texture, null, heldPlayerSlot);
        menu.windowId = windowID;
        minecraft.player.openContainer = menu;
        minecraft.displayGuiScreen(new BuilderInventoryContainerScreen(menu));
    }

    @Override
    public WrapperWorld getClientWorld() {
        return WrapperWorld.getWrapperFor(Minecraft.getMinecraft().world);
    }

    @Override
    public WrapperPlayer getClientPlayer() {
        EntityPlayer player = Minecraft.getMinecraft().player;
        return WrapperPlayer.getWrapperFor(player);
    }

    @Override
    public Point3D getCameraPosition() {
        EntityPlayer player = Minecraft.getMinecraft().player;
        Vec3d cameraOffset = ActiveRenderInfo.getCameraPosition();
        mutablePosition.set(player.posX + cameraOffset.x, player.posY + cameraOffset.y, player.posZ + cameraOffset.z);
        return mutablePosition;
    }

    private static final Point3D mutablePosition = new Point3D();
    private static final FloatBuffer worldModelViewMatrix = BufferUtils.createFloatBuffer(16);
    private static final FloatBuffer worldProjectionMatrix = BufferUtils.createFloatBuffer(16);
    private static final Point3D projectionRenderOrigin = new Point3D();
    private static final Point3D screenProjectionResult = new Point3D();
    private static Entity projectionViewEntity;

    static void captureWorldProjection(float partialTicks) {
        projectionViewEntity = Minecraft.getMinecraft().getRenderViewEntity();
        if (projectionViewEntity == null) {
            return;
        }

        //Capture the world camera, including camera shake, before the hand and GUI replace its matrices.
        worldModelViewMatrix.clear();
        worldProjectionMatrix.clear();
        GL11.glGetFloat(GL11.GL_MODELVIEW_MATRIX, worldModelViewMatrix);
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, worldProjectionMatrix);
        projectionRenderOrigin.set(
                projectionViewEntity.lastTickPosX + (projectionViewEntity.posX - projectionViewEntity.lastTickPosX) * partialTicks,
                projectionViewEntity.lastTickPosY + (projectionViewEntity.posY - projectionViewEntity.lastTickPosY) * partialTicks,
                projectionViewEntity.lastTickPosZ + (projectionViewEntity.posZ - projectionViewEntity.lastTickPosZ) * partialTicks);
    }

    @Override
    public Point3D projectToScreen(Point3D worldPos, int screenWidth, int screenHeight) {
        if (projectionViewEntity == null || projectionViewEntity != Minecraft.getMinecraft().getRenderViewEntity()
                || screenWidth <= 0 || screenHeight <= 0) {
            return null;
        }

        //World rendering uses positions relative to the interpolated render entity.
        //OpenGL matrices are column-major and already include MTS camera adjustments.
        double dx = worldPos.x - projectionRenderOrigin.x;
        double dy = worldPos.y - projectionRenderOrigin.y;
        double dz = worldPos.z - projectionRenderOrigin.z;
        double viewX = worldModelViewMatrix.get(0) * dx + worldModelViewMatrix.get(4) * dy + worldModelViewMatrix.get(8) * dz + worldModelViewMatrix.get(12);
        double viewY = worldModelViewMatrix.get(1) * dx + worldModelViewMatrix.get(5) * dy + worldModelViewMatrix.get(9) * dz + worldModelViewMatrix.get(13);
        double viewZ = worldModelViewMatrix.get(2) * dx + worldModelViewMatrix.get(6) * dy + worldModelViewMatrix.get(10) * dz + worldModelViewMatrix.get(14);
        double viewW = worldModelViewMatrix.get(3) * dx + worldModelViewMatrix.get(7) * dy + worldModelViewMatrix.get(11) * dz + worldModelViewMatrix.get(15);

        double clipX = worldProjectionMatrix.get(0) * viewX + worldProjectionMatrix.get(4) * viewY + worldProjectionMatrix.get(8) * viewZ + worldProjectionMatrix.get(12) * viewW;
        double clipY = worldProjectionMatrix.get(1) * viewX + worldProjectionMatrix.get(5) * viewY + worldProjectionMatrix.get(9) * viewZ + worldProjectionMatrix.get(13) * viewW;
        double clipW = worldProjectionMatrix.get(3) * viewX + worldProjectionMatrix.get(7) * viewY + worldProjectionMatrix.get(11) * viewZ + worldProjectionMatrix.get(15) * viewW;
        if (clipW <= 0.001D) {
            return null;
        }

        double ndcX = clipX / clipW;
        double ndcY = clipY / clipW;
        if (ndcX < -1.1D || ndcX > 1.1D || ndcY < -1.1D || ndcY > 1.1D) {
            return null;
        }

        screenProjectionResult.set(
                (ndcX + 1.0D) / 2.0D * screenWidth,
                (1.0D - ndcY) / 2.0D * screenHeight,
                -viewZ);
        return screenProjectionResult;
    }

    @Override
    public void playBlockBreakSound(Point3D position) {
        BlockPos pos = new BlockPos(position.x, position.y, position.z);
        if (!Minecraft.getMinecraft().world.isAirBlock(pos)) {
            SoundType soundType = Minecraft.getMinecraft().world.getBlockState(pos).getBlock().getSoundType(Minecraft.getMinecraft().world.getBlockState(pos), Minecraft.getMinecraft().player.world, pos, null);
            Minecraft.getMinecraft().world.playSound(Minecraft.getMinecraft().player, pos, soundType.getBreakSound(), SoundCategory.BLOCKS, soundType.getVolume(), soundType.getPitch());
        }
    }

    @Override
    public List<String> getTooltipLines(IWrapperItemStack stack) {
        List<String> tooltipText = ((WrapperItemStack) stack).stack.getTooltip(Minecraft.getMinecraft().player, Minecraft.getMinecraft().gameSettings.advancedItemTooltips ? ITooltipFlag.TooltipFlags.ADVANCED : ITooltipFlag.TooltipFlags.NORMAL);
        //Add grey formatting text to non-first line tooltips.
        for (int i = 1; i < tooltipText.size(); ++i) {
            tooltipText.set(i, TextFormatting.GRAY + tooltipText.get(i));
        }
        return tooltipText;
    }

    /**
     * Tick client-side entities like bullets and particles.
     * These don't get ticked normally due to the world tick event
     * not being called on clients.
     */
    @SubscribeEvent
    public static void onIVClientTick(TickEvent.ClientTickEvent event) {
        IWrapperPlayer player = InterfaceManager.clientInterface.getClientPlayer();
        if (!InterfaceManager.clientInterface.isGamePaused() && player != null) {
            WrapperWorld world = WrapperWorld.getWrapperFor(Minecraft.getMinecraft().world);
            if (world != null) {
                if (event.phase.equals(Phase.START)) {
                    ConfigSystem.displayPendingConfigWarnings(player);
                    ControlSystem.cancelTimedActionsForSpectator(player);
                    if (!player.isSpectator()) {
                        //Handle controls.  This has to happen prior to vehicle updates to ensure click handling is based on current position of the player.
                        ControlSystem.controlGlobal(player);
                        if (((WrapperPlayer) player).player.ticksExisted % 100 == 0) {
                            if (!InterfaceManager.clientInterface.isGUIOpen() && !PackParser.arePacksPresent()) {
                                new GUIPackMissing();
                            }
                        }
                    }

                    world.tickAll(true);

                    //Complain about compats at 10 second mark.
                    if (ConfigSystem.settings.general.performModCompatFunctions.value) {
                        if (ticksToCullingWarning > 0) {
                            if (--ticksToCullingWarning == 0) {
                                //Nothing to complain about here!
                            }
                        }
                    }

                    //Check follower.
                    if (activeFollower != null) {
                        //Follower exists, check if world is the same and it is actually updating.
                        //We check basic states, and then the watchdog bit that gets reset every tick.
                        //This way if we're in the world, but not valid we will know.
                        EntityPlayer mcPlayer = ((WrapperPlayer) player).player;
                        if (activeFollower.world != mcPlayer.world || activeFollower.playerFollowing != mcPlayer || mcPlayer.isDead || activeFollower.isDead || activeFollower.idleTickCounter == 20) {
                            //Follower is not linked.  Remove it and re-create in code below.
                            activeFollower.setDead();
                            activeFollower = null;
                            ticksSincePlayerJoin = 0;
                        } else {
                            ++activeFollower.idleTickCounter;
                        }
                    } else {
                        //Follower does not exist, check if player has been present for 3 seconds and spawn it.
                        if (++ticksSincePlayerJoin == 60) {
                            activeFollower = new BuilderEntityRenderForwarder(((WrapperPlayer) player).player);
                            activeFollower.loadedFromSavedNBT = true;
                            world.world.spawnEntity(activeFollower);
                        }
                    }
                } else {
                    world.tickAll(false);
                    
                    //Handle camera requests.
                    if(cameraModeRequest != null) {
                    	switch(cameraModeRequest) {
	                    	case FIRST_PERSON:{
	                    		Minecraft.getMinecraft().gameSettings.thirdPersonView = 0;
	                    		break;
	                    	}
	                    	case THIRD_PERSON:{
	                    		Minecraft.getMinecraft().gameSettings.thirdPersonView = 1;
	                    		break;
	                    	}
	                    	case THIRD_PERSON_INVERTED:{
	                    		Minecraft.getMinecraft().gameSettings.thirdPersonView = 2;
	                    		break;
	                    	}
                    	}
                    	cameraModeRequest = null;
                    }

                    //Update camera state, since this can change depending on tick if we check during renders.
                    int cameraModeInt = Minecraft.getMinecraft().gameSettings.thirdPersonView;
                    switch(cameraModeInt) {
                    	case(0):{
                    		actualCameraMode = CameraMode.FIRST_PERSON;
                    		break;
                    	}
                    	case(1):{
                    		actualCameraMode = CameraMode.THIRD_PERSON;
                    		break;
                    	}
                    	case(2):{
                    		actualCameraMode = CameraMode.THIRD_PERSON_INVERTED;
                    		break;
                    	}
                    }
                }
            }
        }
    }
}
