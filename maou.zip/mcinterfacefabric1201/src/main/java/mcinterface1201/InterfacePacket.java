package mcinterface1201;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

import io.netty.buffer.ByteBuf;
import minecrafttransportsimulator.mcinterface.AWrapperWorld;
import minecrafttransportsimulator.mcinterface.IInterfacePacket;
import minecrafttransportsimulator.mcinterface.IWrapperNBT;
import minecrafttransportsimulator.mcinterface.IWrapperPlayer;
import minecrafttransportsimulator.mcinterface.InterfaceManager;
import minecrafttransportsimulator.packets.components.APacketBase;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

class InterfacePacket implements IInterfacePacket {
    protected static final ResourceLocation CHANNEL = new ResourceLocation(InterfaceLoader.MODID, "main");
    private static MinecraftServer currentServer;
    private static final BiMap<Byte, Class<? extends APacketBase>> packetMappings = HashBiMap.create();

    /**
     * Called to init this network.  Needs to be done after networking is ready.
     * Packets should be registered at this point in this constructor.
     */
    public static void init() {
        //Fabric: simpan server aktif (dipakai untuk kirim ke semua pemain) dan daftarkan receiver sisi server.
        //Receiver sisi client didaftarkan di InterfacePacketClient (class khusus client).
        ServerLifecycleEvents.SERVER_STARTING.register(server -> currentServer = server);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> currentServer = null);
        ServerPlayNetworking.registerGlobalReceiver(CHANNEL, (server, player, handler, buf, responseSender) -> {
            //Buffer harus dibaca sekarang juga di network thread, sebelum dilepas oleh Fabric.
            WrapperPacket message = WrapperPacket.fromBytes(buf);
            WrapperPacket.handleOnServer(message, server, player);
        });

        //Register internal packets, then external.
        byte packetIndex = 0;
        InterfaceManager.packetInterface.registerPacket(packetIndex++, PacketEntityCSHandshakeClient.class);
        InterfaceManager.packetInterface.registerPacket(packetIndex++, PacketEntityCSHandshakeServer.class);
        APacketBase.initPackets(packetIndex);
    }

    @Override
    public void registerPacket(byte packetIndex, Class<? extends APacketBase> packetClass) {
        packetMappings.put(packetIndex, packetClass);
    }

    @Override
    public byte getPacketIndex(APacketBase packet) {
        return packetMappings.inverse().get(packet.getClass());
    }

    @Override
    public void sendToServer(APacketBase packet) {
        InterfacePacketClient.sendToServer(toBuffer(packet));
    }

    @Override
    public void sendToAllClients(APacketBase packet) {
        if (currentServer != null) {
            FriendlyByteBuf buf = toBuffer(packet);
            for (ServerPlayer serverPlayer : currentServer.getPlayerList().getPlayers()) {
                ServerPlayNetworking.send(serverPlayer, CHANNEL, PacketByteBufs.copy(buf));
            }
        }
    }

    @Override
    public void sendToPlayer(APacketBase packet, IWrapperPlayer player) {
        ServerPlayNetworking.send((ServerPlayer) ((WrapperPlayer) player).player, CHANNEL, toBuffer(packet));
    }

    /**
     * Gets the world this packet was sent from based on its context.
     * Used for handling packets arriving on the server.
     */
    private static FriendlyByteBuf toBuffer(APacketBase packet) {
        FriendlyByteBuf buf = PacketByteBufs.create();
        new WrapperPacket(packet).toBytes(buf);
        return buf;
    }

    @Override
    public void writeDataToBuffer(IWrapperNBT data, ByteBuf buf) {
        //We know this will be a PacketBuffer, so we can cast rather than wrap.
        ((FriendlyByteBuf) buf).writeNbt(((WrapperNBT) data).tag);
    }

    @Override
    public WrapperNBT readDataFromBuffer(ByteBuf buf) {
        return new WrapperNBT(((FriendlyByteBuf) buf).readNbt());
    }

    /**
     * Custom class for packets.  Allows for a common packet to be used for all MC versions,
     * as well as less boilerplate code due to thread operations.  Note that when this packet
     * arrives on the other side of the pipeline, MC won't know what class to construct.
     * That's up to us to handle via the packet's first byte.  Also note that this class
     * must be public, as if it is private MC won't be able to construct it due to access violations.
     */
    public static class WrapperPacket {
        private APacketBase packet;

        /**
         * Do NOT call!  Dipertahankan agar kompatibel dengan versi Forge.
         **/
        public WrapperPacket() {
        }

        public WrapperPacket(APacketBase packet) {
            this.packet = packet;
        }

        public static WrapperPacket fromBytes(FriendlyByteBuf buf) {
            byte packetIndex = buf.readByte();
            Class<? extends APacketBase> packetClass = packetMappings.get(packetIndex);
            if (packetClass == null) {
                throw new IndexOutOfBoundsException("Was asked to create packet of index " + packetIndex + " but we haven't registered that one yet!");
            }
            try {
                return new WrapperPacket(packetClass.getConstructor(ByteBuf.class).newInstance(buf));
            } catch (Exception e) {
                e.printStackTrace();
                throw new IllegalStateException("Was asked to create packet of " + packetClass.getSimpleName() + " but couldn't due to an error.  Something went VERY wrong here.  Check the log for more information.");
            }
        }

        public void toBytes(FriendlyByteBuf buf) {
            packet.writeToBuffer(buf);
        }

        /**Dipanggil di network thread server saat paket dari client tiba.*/
        public static void handleOnServer(WrapperPacket message, MinecraftServer server, ServerPlayer sender) {
            if (message.packet.runOnMainThread()) {
                //Need to put this in a runnable to not run it on the network thread and get a CME.
                server.execute(() -> message.packet.handleFromClient(WrapperWorld.getWrapperFor(sender.level()), WrapperPlayer.getWrapperFor(sender)));
            } else {
                message.packet.handleFromClient(WrapperWorld.getWrapperFor(sender.level()), WrapperPlayer.getWrapperFor(sender));
            }
        }

        /**Dipanggil di network thread client saat paket dari server tiba.  Hanya dipanggil dari InterfacePacketClient.*/
        public static void handleOnClient(WrapperPacket message, net.minecraft.client.Minecraft client) {
            if (message.packet.runOnMainThread()) {
                client.execute(() -> {
                    AWrapperWorld world = InterfaceManager.clientInterface.getClientWorld();
                    if (world != null) {
                        message.packet.handle(world);
                    }
                });
            } else {
                message.packet.handle(InterfaceManager.clientInterface.getClientWorld());
            }
        }
    }
}
