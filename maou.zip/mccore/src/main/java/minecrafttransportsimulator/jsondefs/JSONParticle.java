package minecrafttransportsimulator.jsondefs;

import java.util.List;

import minecrafttransportsimulator.baseclasses.ColorRGB;
import minecrafttransportsimulator.baseclasses.Point3D;
import minecrafttransportsimulator.baseclasses.RotationMatrix;
import minecrafttransportsimulator.packloading.JSONParser.JSONDescription;
import minecrafttransportsimulator.packloading.JSONParser.JSONRequired;

public class JSONParticle {
    @JSONRequired
    @JSONDescription("Which type of particle to use.")
    public ParticleType type;

    @JSONDescription("Foces this particle to spawn every tick it is active.  Useful for constant particle flows, like smoke.")
    public boolean spawnEveryTick;
    
    @JSONDescription("If true, the particle will use the block color of the block it is spawned from.  Valid only on break type particles.")
    public boolean useBlockColor;
    
    @JSONDescription("If true, the particle will use the block properties from the ground below it, no matter how far down the ground is, vs the properties of the block at the position it is at.")
    public boolean getBlockPropertiesFromGround;

    @JSONDescription("If true, this particle will ignore lighting and will render bright at all times.  Useful for muzzle flashes and sparks.")
    public boolean isBright;

    @JSONDescription("If true, this particle will do brightness blending.  Ignored if the user has blendedLights as false in their config.")
    public boolean isBlended;

    @JSONDescription("Reduces alpha by this factor during daytime.  A value of 1 means the particle will be invisible during full daylight, decimals (0.0->1.0) for partial brightness during daytime are supported.")
    public float daytimeReductionFactor;

    @JSONDescription("Makes the particle stop all movement when it hits the ground.  This includes rotation.")
    public boolean stopsOnGround;

    @JSONDescription("Makes the particle ignore collision with all blocks.  Can and should be used on particles that don't need collision, since this takes up CPU cycles and can lead to odd behavior on occasion if particles are spawned inside blocks.")
    public boolean ignoreCollision;

    @JSONDescription("A random sound from this list of sounds will play when the particle stops on the ground when stopsOnGround is true.  Format for each entry is [packID:soundName]")
    public List<String> groundSounds;

    @JSONRequired
    @JSONDescription("The orientation this particle spawns about.")
    public ParticleSpawningOrientation spawningOrientation;

    @JSONRequired
    @JSONDescription("The orientation this particle rotates.")
    public ParticleRenderingOrientation renderingOrientation;

    @JSONDescription("How many of this particle to spawn at a time. Defaults to 1.")
    public int quantity;

    @JSONDescription("How far apart individual particles should spawn, in blocks.  Note that this overrides spawing rates and will be checked every frame.  Use sparingly!")
    public float distance;

    @JSONDescription("How long, in ticks, the particle should remain.  If not set on a defined type, the age will be auto-calculated the same way it would be for a Vanilla particle.  Defaults to 200 on any other types.")
    public int duration;

    @JSONDescription("Duration will have this value added/subtracted to it by a random factor when created.  Allows for shorter/longer duration particles.")
    public int durationRandomness;

    @JSONDescription("If set, the particle will linearly change its speed from the intialVelocity, to 0, after this many ticks.  If the particle is still present after this, it will not move.  If the particle's duration is less than this value, then the particle will only slow down according to the linear interpolation and will never stop. Note that movementVelocity and terminalVelocity is still applied if applicable, so the velocity may not follow this exact value if those are present.")
    public int movementDuration;

    @JSONDescription("A number between 0.0 and 1.0 describing how transparent the particle should be.  If both this and toTransparency are not set, they are assumed to be 1.0 for both and no transparency changes will be performed.")
    public float transparency;

    @JSONDescription("Like above, but tells the particle to gradually change from its initial transparency to this value.  If transparency is set and non-zero, then this defaults to 0.0.  Othwerise, it is used as-is.")
    public float toTransparency;

    @JSONDescription("The time, in ticks, for the particle to fade in at the start of its lifespan.  Particles fade by multiplying their defined alpha times the relative time-value of this value.  So if fade-in time is 10, and the particle is 5 ticks from spawn, alpha will be half of what is defined (5/10).")
    public int fadeInTransparencyTime;

    @JSONDescription("The time, in ticks, for the particle to fade out at the end of its lifespan.  Particles fade by multiplying their defined alpha times the relative time-value of this value.  So if fade-out time is 40, and the particle is 20 ticks from death, alpha will be half of what is defined (20/40).")
    public int fadeOutTransparencyTime;

    @JSONDescription("How big to spawn each particle.  A value of 1.0 will result in 1 pixel of the particle texture per 1 pixel in-game.  May be a single number, or an [X, Y, Z] array.  This is the default if this is not set.")
    public Point3D scale;

    @JSONDescription("Like above, but tells the particle to gradually change from its initial scale to this value.  Defaults to 1.0 if this and scale are not set.")
    public float toScale;

    @JSONDescription("Random fraction of the rendered scale to add or subtract. A value of 0.25 gives a multiplier between 0.75 and 1.25. Defaults to 0 if are not set.")
    public float scaleRandomness;

    @JSONDescription("The time, in ticks, for the particle to scale in at the start of its lifespan.  Particles scale by multiplying their defined scale times the relative time-value of this value.  So if fade-in time is 10, and the particle is 5 ticks from spawn, scale will be half of what is defined (5/10).")
    public int fadeInScaleTime;

    @JSONDescription("The time, in ticks, for the particle to scale out at the end of its lifespan.  Particles scale by multiplying their defined scale times the relative time-value of this value.  So if fade-out time is 40, and the particle is 20 ticks from death, scale will be half of what is defined (20/40).")
    public int fadeOutScaleTime;

    @JSONDescription("The size of the hitbox.  Defaults to 0.2 for all particles except break, which are 0.1, if not set.")
    public float hitboxSize;

    @JSONDescription("Normally particles use built-in textures.  However, one can specify a texture sheet to use if they wish.  Format is packID:path/to/texture.")
    public String texture;

    @JSONDescription("Normally particles use a 2D model to render as a flat texture.  However, one can specify a model to use here for full 3D objects.  Format is packID:path/to/model.")
    public String model;

    @JSONDescription("If you want your particle to have multiple textures, you can specify the texture PNG files to use here.  The delay between each texture segment is goverend by the textureDelay variable, if it is set.  If you delay past the last texture, the cycle repeats.")
    public List<String> textureList;

    @JSONDescription("A list of delays between cycling to the next texture.  If the end of this list is reached, the delay sequence will repeat from the start of the list.")
    public List<Integer> textureDelays;

    @JSONDescription("Normally, textureList starts with the first texture.  Setting this true starts from a random spot.  If textureDelays is null, then it'll just pick a random texture and stick with it.  Otherwise, it will cycle as normal.")
    public boolean randomTexture;

    @JSONDescription("If you want your particle to have multiple colors, you can specify the colors to use here.  The delay between each color is goverend by the colorDelay variable, if it is set.  If you delay past the last color, the cycle repeats.")
    public List<ColorRGB> colorList;

    @JSONDescription("A list of delays between cycling to the next color.  If the end of this list is reached, the delay sequence will repeat from the start of the list.")
    public List<Integer> colorDelays;

    @JSONDescription("Normally, colorList starts with the first color.  Setting this true starts from a random spot.  If colorDelays is null, then it'll just pick a random color and stick with it.  Otherwise, it will cycle as normal.")
    public boolean randomColor;

    @JSONDescription("A string in hexadecimal format representing the particle's color.  Defaults to white if not set, which essentially does no color modification.")
    public ColorRGB color;

    @JSONDescription("Like above, but tells the particle to gradually change from its initial color to this value.  Defaults to be the same as the initial color.")
    public ColorRGB toColor;

    @JSONDescription("The position where this particle should be spawned relative to the spawning object.  May be left out if the particle should spawn at the same position.")
    public Point3D pos;

    @JSONDescription("The rotation to rotate this particle to.  Only has an effect for FIXED orientation particles, as do all other rotational parameters.")
    public RotationMatrix rot;

    @JSONDescription("These angles will be randomly added to rot, multipled by a random value between -1 and 1.")
    public Point3D rotationRandomness;

    @JSONDescription("The angles to rotate this particle by every tick.")
    public Point3D rotationVelocity;

    @JSONDescription("This velocity will be randomly added to the initialVelocity, multipled by a random value between -1 and 1.")
    public Point3D spreadRandomness;

    @JSONDescription("The factor of which to inherit the spawning velocity of the thing that is producing it, where +Z is straight ahead relative to the thing that is producing it.  If left out, no inherited velocity is assumed.")
    public Point3D relativeInheritedVelocityFactor;

    @JSONDescription("The initial velocity of the particle, where +Z is straight ahead relative to the thing that is producing it.  May be omitted to make a particle that doesn't spawn with any initial velocity except the velocity of the object spawning it.")
    public Point3D initialVelocity;

    @JSONDescription("The velocity to apply every tick to the particle.  This can be used to make smoke float up, oil drip down, etc.  If this and relativeMovementVelocity is not set, the default particle velocity is used.")
    public Point3D movementVelocity;

    @JSONDescription("The velocity to apply every tick to the particle, relative the the particle itself.  This differs from movementVelocity, which is relative to the world.")
    public Point3D relativeMovementVelocity;

    @JSONDescription("The max velocity this particle can have in any axis.  Used to prevent particles from going to fast if they move a long way.")
    public Point3D terminalVelocity;

    @JSONDescription("This is a list of animatedObjects that can be used to move the spawn position of this particle.")
    public List<JSONAnimationDefinition> spawningAnimations;

    @JSONRequired
    @JSONDescription("A listing of animation objects for determining if this particle should spawn.  Particles will only spawn when they first become active, unless spawnEveryTick is set.")
    public List<JSONAnimationDefinition> activeAnimations;

    @JSONDescription("A list of sub-particles this particle can spawn.  They will be spawned when their conditions are met.  Note that sub-particles do not reference spawningAnimations or activeAnimations.")
    public List<JSONSubParticle> subParticles;

    @JSONDescription("A dynamic light this particle gives off, with the same fields as a light's blendableComponents entry: isDynamicLight or a lightPreset makes it light the world (otherwise it does nothing), beamIntensity, lightReach, lightAngle, beamSoftness, beamDiameter with beamLength, lightBeamLength, shadowStartDistance, and flareWidth or flareHeight for a corona (bloomIntensity scales it).  pos is relative to the particle and defaults to its center; axis, also turned with the particle, makes it a spot, and no axis makes a point light.  Its color defaults to the particle's current color, and its brightness follows the particle's transparency (clamped to 0 to 1; daytimeReductionFactor against the daylight on the particle), so it fades and changes color with the particle.  Particle lights rank below every lamp, and point lights within 1.5 blocks of each other add up into one light.  Sub-particles do not inherit it.")
    public JSONLight.JSONLightBlendableComponent light;

    @Deprecated
    public int fadeScaleTime;

    @Deprecated
    public int fadeTransparencyTime;

    @Deprecated
    public Point3D velocityVector;

    @Deprecated
    public float spreadFactorHorizontal;

    @Deprecated
    public float spreadFactorVertical;

    @Deprecated
    public boolean axisAligned;

    public static class JSONSubParticle {

        @JSONDescription("The particle to spawn.")
        public JSONParticle particle;

        @JSONDescription("The time, in ticks, at which to spawn the particle.")
        public int time;
    }

    public enum ParticleSpawningOrientation {
        @JSONDescription("Particle spawns relative to the entity that spawned it.")
        ENTITY,
        @JSONDescription("Particle spawns attached to the entity that spawned it, and moves with that entity.")
        ATTACHED,
        @JSONDescription("Particle spawns attached to the entity that spawned it, and moves with that entity, but the texture will be rotated for the Z axis.")
        ATTACHED_Z,
        @JSONDescription("Particle spawns relative to the particle before it, creating a continuous streak of particles.")
        STREAK,
        @JSONDescription("Particle spawns as a segment between the previous and current spawn positions, with the horizontal texture axis aligned to the local Z-axis.")
        TRAIL,
        @JSONDescription("Particle spawns relative to the world and ignores entity orientation.")
        WORLD,
        @JSONDescription("Particle spawns relative to the world and ignores entity orientation, but moves with the entity that spawned it.")
        WORLD_ATTACHED,
        @JSONDescription("Particle spawns relative to to the face orientation where the bullet that spawned it hit.  If this is an air burst that didn't hit anything, or isn't on a bullet, it will not be spawned.")
        FACING;
    }

    public enum ParticleRenderingOrientation {
        @JSONDescription("Particle does not rotate and orients as spawned.")
        FIXED,
        @JSONDescription("Particle rotates to always face the player.")
        PLAYER,
        @JSONDescription("Particle rotates to face the player, but only about the Y-axis.")
        YAXIS,
        @JSONDescription("Particle rotates to face the player, with particle rotation constrained to the Z-axis relative to the player camera.")
        ZAXIS,
        @JSONDescription("Particle rotates to face its motion.  Think bullets.")
        MOTION;
    }

    public enum ParticleType {
        @JSONDescription("The standard smoke particle.")
        SMOKE,
        @JSONDescription("The standard (torch) flame particle.")
        FLAME,
        @Deprecated
        DRIP,
        @JSONDescription("The standard bubble particle.")
        BUBBLE,
        @JSONDescription("The standard block breakage particle. The block texture to use will always be the block below this particle when first spawned.")
        BREAK,
        @JSONDescription("A casing particle.  This renders the model/texture as defined on the bullet in the gun that spawns this.")
        CASING,
        @JSONDescription("A generic particle.  This has no movement by default, so you will have to specify it.")
        GENERIC
    }
}
