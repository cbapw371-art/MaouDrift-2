package mcinterface1201.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;

import mcinterface1201.InterfaceEventsEntityRendering;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;

/**
 * Replacement for Forge's ViewportEvent.ComputeCameraAngles.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Shadow
    private Camera mainCamera;

    @Inject(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setup(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;ZZF)V", shift = At.Shift.AFTER))
    private void inject_ivCameraSetup(float partialTicks, long finishTimeNano, PoseStack poseStack, CallbackInfo ci) {
        InterfaceEventsEntityRendering.onIVCameraSetup(mainCamera, partialTicks, poseStack);
    }
}
