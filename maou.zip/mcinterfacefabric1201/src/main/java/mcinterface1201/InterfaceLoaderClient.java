package mcinterface1201;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screens.MenuScreens;

/**
 * Titik masuk client untuk Fabric.  Di Forge, bagian ini dilakukan lewat
 * event mod bus (RegisterKeyMappings, RegisterShaders, RegisterRenderers, FMLClientSetup).
 * Dipanggil Fabric setelah InterfaceLoader.onInitialize() selesai, jadi semua registry sudah terisi.
 */
public class InterfaceLoaderClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        InterfaceInput.registerKeyMappings();
        InterfacePacketClient.registerReceiver();
        InterfaceClient.registerEvents();
        InterfaceSound.registerEvents();
        InterfaceRender.registerClientEvents();
        InterfaceEventsEntityRendering.registerClientEvents();
        WrapperWorld.registerClientEvents();
        WrapperEntity.registerClientEvents();
        WrapperPlayer.registerClientEvents();
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents.ENTITY_UNLOAD.register((unloadedEntity, world) -> BuilderEntityExisting.onIVEntityUnload(unloadedEntity));
        MenuScreens.register(BuilderInventoryContainerMenu.TYPE.get(), BuilderInventoryContainerScreen::new);
    }
}
