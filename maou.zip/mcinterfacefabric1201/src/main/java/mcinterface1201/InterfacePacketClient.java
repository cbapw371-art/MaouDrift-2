package mcinterface1201;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;

/**
 * Bagian jaringan yang hanya ada di client.  Dipisah dari {@link InterfacePacket}
 * supaya server dedicated tidak mencoba me-load class client Fabric.
 */
public class InterfacePacketClient {
    public static void registerReceiver() {
        ClientPlayNetworking.registerGlobalReceiver(InterfacePacket.CHANNEL, (client, handler, buf, responseSender) -> {
            //Buffer harus dibaca sekarang juga di network thread.
            InterfacePacket.WrapperPacket message = InterfacePacket.WrapperPacket.fromBytes(buf);
            InterfacePacket.WrapperPacket.handleOnClient(message, client);
        });
    }

    public static void sendToServer(FriendlyByteBuf buf) {
        ClientPlayNetworking.send(InterfacePacket.CHANNEL, buf);
    }
}
