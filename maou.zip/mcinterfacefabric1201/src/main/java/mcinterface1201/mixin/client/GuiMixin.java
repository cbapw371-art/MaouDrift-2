package mcinterface1201.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import mcinterface1201.InterfaceEventsEntityRendering;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;

/**
 * Replacement for Forge's RenderGuiOverlayEvent.Pre blocking of vanilla overlays.
 */
@Mixin(Gui.class)
public abstract class GuiMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void inject_ivCrosshair(GuiGraphics graphics, CallbackInfo ci) {
        if (InterfaceEventsEntityRendering.shouldCancelCrosshair()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void inject_ivHotbar(float partialTicks, GuiGraphics graphics, CallbackInfo ci) {
        if (InterfaceEventsEntityRendering.shouldCancelHotbar()) {
            ci.cancel();
        }
    }

    //Covers health, armor, and food.
    @Inject(method = "renderPlayerHealth", at = @At("HEAD"), cancellable = true)
    private void inject_ivPlayerHealth(GuiGraphics graphics, CallbackInfo ci) {
        if (InterfaceEventsEntityRendering.shouldCancelStatusOverlay()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderExperienceBar", at = @At("HEAD"), cancellable = true)
    private void inject_ivExperienceBar(GuiGraphics graphics, int xPos, CallbackInfo ci) {
        if (InterfaceEventsEntityRendering.shouldCancelStatusOverlay()) {
            ci.cancel();
        }
    }
}
