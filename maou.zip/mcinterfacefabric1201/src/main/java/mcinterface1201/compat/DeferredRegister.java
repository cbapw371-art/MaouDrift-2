package mcinterface1201.compat;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;

/**
 * Pengganti ringan net.minecraftforge.registries.DeferredRegister untuk Fabric.
 * Supplier disimpan dulu, lalu semuanya didaftarkan ke registry saat {@link #flush()}
 * dipanggil.  Urutan flush diatur oleh InterfaceLoader (block -> item -> block entity
 * -> entity -> menu -> creative tab) supaya sama seperti urutan registry vanilla di Forge.
 */
public class DeferredRegister<T> {
    private final Registry<T> registry;
    private final String modID;
    private final List<Runnable> pending = new ArrayList<>();

    private DeferredRegister(Registry<T> registry, String modID) {
        this.registry = registry;
        this.modID = modID;
    }

    public static <T> DeferredRegister<T> create(Registry<T> registry, String modID) {
        return new DeferredRegister<>(registry, modID);
    }

    @SuppressWarnings("unchecked")
    public <I extends T> RegistryObject<I> register(String name, Supplier<? extends I> supplier) {
        ResourceLocation id = new ResourceLocation(modID, name);
        RegistryObject<I> object = new RegistryObject<>(id);
        pending.add(() -> {
            I value = supplier.get();
            Registry.register(registry, id, value);
            object.set(value);
        });
        return object;
    }

    /**Daftarkan semua entri yang tertunda.  Aman dipanggil berulang kali.*/
    public void flush() {
        //Salin dulu, karena supplier bisa saja menambah entri baru.
        while (!pending.isEmpty()) {
            List<Runnable> copy = new ArrayList<>(pending);
            pending.clear();
            copy.forEach(Runnable::run);
        }
    }
}
