package mcinterface1201;

import mcinterface1201.compat.RegistryObject;
import minecrafttransportsimulator.blocks.tileentities.components.ATileEntityBase;
import minecrafttransportsimulator.blocks.tileentities.components.ITileEntityInventoryProvider;
import minecrafttransportsimulator.entities.instances.EntityInventoryContainer;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builder for tile entities that contain inventories.  This builder ticks.
 * Versi Fabric: inventory MTS dibungkus sebagai {@link Container} vanilla, lalu diekspos lewat
 * Fabric Transfer API ({@link InventoryStorage}) sebagai pengganti IItemHandler/ForgeCapabilities.
 *
 * @author don_bruce
 */
public class BuilderTileEntityInventoryContainer extends BuilderTileEntity {
    protected static RegistryObject<BlockEntityType<BuilderTileEntityInventoryContainer>> TE_TYPE2;

    private EntityInventoryContainer inventory;
    private final MTSContainer container = new MTSContainer();

    public BuilderTileEntityInventoryContainer(BlockPos pos, BlockState state) {
        super(TE_TYPE2.get(), pos, state);
    }

    /**Dipanggil InterfaceLoader setelah registry di-flush.  Menggantikan getCapability(ITEM_HANDLER).*/
    public static void registerStorage() {
        ItemStorage.SIDED.registerForBlockEntity((be, side) -> (side == Direction.UP || side == Direction.DOWN) ? InventoryStorage.of(be.container, side) : null, TE_TYPE2.get());
    }

    @Override
    protected void setTileEntity(ATileEntityBase<?> tile) {
        super.setTileEntity(tile);
        this.inventory = ((ITileEntityInventoryProvider) tile).getInventory();
    }

    private ItemStack getStackInSlot(int index) {
        return inventory != null ? ((WrapperItemStack) inventory.getStack(index)).stack : ItemStack.EMPTY;
    }

    private void putStackInSlot(int index, ItemStack stack) {
        if (inventory != null) {
            inventory.setStack(new WrapperItemStack(stack), index);
        }
    }

    /**Pembungkus inventory MTS sebagai Container vanilla untuk dipakai InventoryStorage.*/
    private class MTSContainer implements Container {
        @Override
        public int getContainerSize() {
            return inventory != null ? inventory.getSize() : 0;
        }

        @Override
        public boolean isEmpty() {
            for (int i = 0; i < getContainerSize(); ++i) {
                if (!getStackInSlot(i).isEmpty()) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public ItemStack getItem(int slot) {
            return getStackInSlot(slot);
        }

        @Override
        public ItemStack removeItem(int slot, int amount) {
            ItemStack stack = getStackInSlot(slot);
            ItemStack extracted = stack.split(amount);
            putStackInSlot(slot, stack);
            return extracted;
        }

        @Override
        public ItemStack removeItemNoUpdate(int slot) {
            ItemStack stack = getStackInSlot(slot).copy();
            putStackInSlot(slot, ItemStack.EMPTY);
            return stack;
        }

        @Override
        public void setItem(int slot, ItemStack stack) {
            putStackInSlot(slot, stack);
        }

        @Override
        public int getMaxStackSize() {
            return 64;
        }

        @Override
        public void setChanged() {
            //MTS menyimpan data sendiri lewat EntityInventoryContainer.
        }

        @Override
        public boolean stillValid(Player player) {
            return false;
        }

        @Override
        public void clearContent() {
            for (int i = 0; i < getContainerSize(); ++i) {
                putStackInSlot(i, ItemStack.EMPTY);
            }
        }
    }
}
