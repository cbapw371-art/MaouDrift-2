package mcinterface1201;

import java.util.Collections;
import java.util.Iterator;

import mcinterface1201.compat.RegistryObject;
import minecrafttransportsimulator.blocks.tileentities.components.ATileEntityBase;
import minecrafttransportsimulator.blocks.tileentities.components.ITileEntityFluidTankProvider;
import minecrafttransportsimulator.blocks.tileentities.instances.TileEntityFluidLoader;
import minecrafttransportsimulator.entities.instances.EntityFluidTank;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.fabricmc.fabric.api.transfer.v1.transaction.base.SnapshotParticipant;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;

/**
 * Builder for tile entities that contain fluids.  This builder ticks.
 * Versi Fabric: memakai Fabric Transfer API (Storage&lt;FluidVariant&gt;) sebagai pengganti
 * IFluidHandler/ForgeCapabilities.  Satuan tank MTS adalah mB, sedangkan Fabric memakai
 * droplet (1 mB = 81 droplet), jadi ada konversi di sini.
 *
 * @author don_bruce
 */
public class BuilderTileEntityFluidTank extends BuilderTileEntity {
    protected static RegistryObject<BlockEntityType<BuilderTileEntityFluidTank>> TE_TYPE2;
    private static final long DROPLETS_PER_MB = FluidConstants.BUCKET / 1000;

    private EntityFluidTank tank;
    private final TankStorage storage = new TankStorage();

    public BuilderTileEntityFluidTank(BlockPos pos, BlockState state) {
        super(TE_TYPE2.get(), pos, state);
    }

    /**Dipanggil InterfaceLoader setelah registry di-flush.  Menggantikan getCapability(FLUID_HANDLER).*/
    public static void registerStorage() {
        FluidStorage.SIDED.registerForBlockEntity((be, side) -> side == Direction.DOWN ? be.storage : null, TE_TYPE2.get());
    }

    @Override
    protected void setTileEntity(ATileEntityBase<?> tile) {
        super.setTileEntity(tile);
        this.tank = ((ITileEntityFluidTankProvider) tile).getTank();
    }

    @Override
    public void tick() {
        super.tick();
        if (tank != null) {
            if (tileEntity instanceof TileEntityFluidLoader && ((TileEntityFluidLoader) tileEntity).isUnloader()) {
                if (getFluidAmount() > 0) {
                    //Pump out fluid to storage below, if we have one.
                    Storage<FluidVariant> below = FluidStorage.SIDED.find(level, getBlockPos().below(), Direction.UP);
                    if (below != null) {
                        try (Transaction transaction = Transaction.openOuter()) {
                            StorageUtil.move(storage, below, variant -> true, getFluidAmount() * DROPLETS_PER_MB, transaction);
                            transaction.commit();
                        }
                    }
                }
            }
        }
    }

    private int getFluidAmount() {
        return (int) (tank != null ? tank.getFluidLevel() : 0);
    }

    private FluidVariant getFluidVariant() {
        if (tank != null && !tank.getFluid().isEmpty()) {
            //Fluid disimpan MTS hanya dengan nama (path), jadi cari fluid dengan path yang sama.
            for (ResourceLocation fluidKey : BuiltInRegistries.FLUID.keySet()) {
                if (fluidKey.getPath().equals(tank.getFluid())) {
                    return FluidVariant.of(BuiltInRegistries.FLUID.get(fluidKey));
                }
            }
        }
        return FluidVariant.blank();
    }

    /**
     * Storage satu slot yang membungkus {@link EntityFluidTank}.  Mendukung rollback transaksi
     * lewat snapshot (fluid, mod, level).
     */
    private class TankStorage extends SnapshotParticipant<Object[]> implements SingleSlotStorage<FluidVariant> {
        @Override
        public long insert(FluidVariant resource, long maxAmount, TransactionContext transaction) {
            if (tank == null || resource.isBlank() || resource.getFluid() == Fluids.EMPTY) {
                return 0;
            }
            ResourceLocation location = BuiltInRegistries.FLUID.getKey(resource.getFluid());
            long maxMb = maxAmount / DROPLETS_PER_MB;
            //Cek dulu berapa yang muat, baru ambil snapshot kalau memang ada yang masuk.
            long possible = (long) tank.fill(location.getPath(), location.getNamespace(), maxMb, false);
            if (possible > 0) {
                updateSnapshots(transaction);
                long filled = (long) tank.fill(location.getPath(), location.getNamespace(), possible, true);
                return filled * DROPLETS_PER_MB;
            }
            return 0;
        }

        @Override
        public long extract(FluidVariant resource, long maxAmount, TransactionContext transaction) {
            if (tank == null || resource.isBlank() || resource.getFluid() == Fluids.EMPTY) {
                return 0;
            }
            ResourceLocation location = BuiltInRegistries.FLUID.getKey(resource.getFluid());
            long maxMb = maxAmount / DROPLETS_PER_MB;
            long possible = (long) tank.drain(location.getPath(), location.getNamespace(), maxMb, false);
            if (possible > 0) {
                updateSnapshots(transaction);
                long drained = (long) tank.drain(location.getPath(), location.getNamespace(), possible, true);
                return drained * DROPLETS_PER_MB;
            }
            return 0;
        }

        @Override
        public boolean isResourceBlank() {
            return getFluidAmount() == 0;
        }

        @Override
        public FluidVariant getResource() {
            return getFluidVariant();
        }

        @Override
        public long getAmount() {
            return getFluidAmount() * DROPLETS_PER_MB;
        }

        @Override
        public long getCapacity() {
            return tank != null ? tank.getMaxLevel() * DROPLETS_PER_MB : 0;
        }

        @Override
        protected Object[] createSnapshot() {
            return tank != null ? new Object[] { tank.getFluid(), tank.getFluidMod(), tank.getFluidLevel() } : new Object[] { "", "", 0D };
        }

        @Override
        protected void readSnapshot(Object[] snapshot) {
            if (tank != null) {
                tank.manuallySet((String) snapshot[0], (String) snapshot[1], (Double) snapshot[2]);
            }
        }

        @Override
        public Iterator<StorageView<FluidVariant>> iterator() {
            return Collections.<StorageView<FluidVariant>>singletonList(this).iterator();
        }
    }
}
