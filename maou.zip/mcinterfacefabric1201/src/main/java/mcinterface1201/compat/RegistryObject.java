package mcinterface1201.compat;

import java.util.function.Supplier;

import net.minecraft.resources.ResourceLocation;

/**
 * Pengganti ringan net.minecraftforge.registries.RegistryObject untuk Fabric.
 * Nilainya baru tersedia setelah {@link DeferredRegister#flush()} dipanggil.
 */
public class RegistryObject<T> implements Supplier<T> {
    private final ResourceLocation id;
    private T value;

    RegistryObject(ResourceLocation id) {
        this.id = id;
    }

    void set(T value) {
        this.value = value;
    }

    @Override
    public T get() {
        if (value == null) {
            throw new IllegalStateException("Registry object belum terdaftar: " + id);
        }
        return value;
    }

    public boolean isPresent() {
        return value != null;
    }

    public ResourceLocation getId() {
        return id;
    }
}
